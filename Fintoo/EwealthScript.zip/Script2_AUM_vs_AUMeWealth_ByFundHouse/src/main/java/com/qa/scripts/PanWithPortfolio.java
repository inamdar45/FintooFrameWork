package com.qa.scripts;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.Duration;

import org.apache.poi.openxml4j.util.ZipSecureFile;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.qa.base.TestBase;
import com.qa.util.Xls_Reader;

public class PanWithPortfolio extends TestBase{
	Xls_Reader writer;
	String username = prop.getProperty("username");
	String password = prop.getProperty("password");
	Xls_Reader reader = new Xls_Reader("./src/main/java/com/qa/testdata/WBR1.xlsx");

  
	public void panWithPortfolio() throws IOException, InterruptedException {
		getDriver().findElement(By.xpath("//input[@name='EmailID']")).sendKeys(username);
		getDriver().findElement(By.xpath("//input[@name='Password']")).sendKeys(password);
		getDriver().findElement(By.xpath("//button[@name='loginbtn']")).click();
		//Thread.sleep(8000);
		Workbook wb = new XSSFWorkbook();
		FileOutputStream fileout = new FileOutputStream("D:\\PortfoliosPAN.xlsx");
		ZipSecureFile.setMinInflateRatio(0);
		wb.write(fileout);
		fileout.close();
	    writer = new Xls_Reader("D:\\PortfoliosPAN.xlsx");
		writer.addSheet("Sheet-1");
		writer.addColumn("Sheet-1", "PAN");
		
		getDriver().get("http://www.financialhospital.in/adminpanel/leads/viewsearchlead.php");
		//Thread.sleep(8000);//
		getDriver().findElement(By.xpath("//button[@id='btn-show-reco-filter']")).click();
	//	Thread.sleep(2000);
		getDriver().findElement(By.xpath("/html[1]/body[1]/div[1]/div[7]/div[1]/div[2]/div[2]/form[1]/fieldset[1]/div[1]/div[2]/div[1]/div[2]/div[1]/span[1]/div[1]/button[1]"))
				.click();
	//	Thread.sleep(5000);
		getDriver().findElement(By.xpath("//div[@class='btn-group open']//li[@class='multiselect-item multiselect-all']//input"))
				.click();
		getDriver().findElement(By.xpath("//button[@name='searchbtn']")).click();
		int crmMFincrement = 2;
		int rowIncrement = 2;
		int rowCount = reader.getRowCount("Sheet1");
		for (int rowNum = 1; rowNum < rowCount; rowNum++) { 
			
			
			
			getDriver().get("http://www.financialhospital.in/adminpanel/leads/viewsearchlead.php");
			//Thread.sleep(6000);//
			getDriver().findElement(By.xpath("//input[@type='search']"))
					.sendKeys(reader.getCellData("Sheet1", "PAN", rowNum));
			getDriver().findElement(By.xpath("//input[@type='search']")).sendKeys(Keys.ENTER);
			
			if (getDriver().findElement(By.xpath(
					"/html[1]/body[1]/div[1]/div[7]/div[1]/div[3]/div[2]/form[1]/div[2]/table[1]/tbody[1]/tr[1]/td[2]/span[1]")) != null) {
					Thread.sleep(3000);	
					
				try {
					//Thread.sleep(10000);
				//if(fluentWait(getDriver(), getDriver().findElement(By.xpath("/html[1]/body[1]/div[1]/div[7]/div[1]/div[3]/div[2]/form[1]/div[2]/table[1]/tbody[1]/tr[1]/td[2]/span[1]")), 10, 1)) 	
				//	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//table[@id='datatable-new']/tbody/tr/td[6]")));
					String pan=reader.getCellData("Sheet1", "PAN", rowNum);
					WebDriverWait wait=new WebDriverWait(getDriver(),10);
					WebElement element=wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='"+pan+"']")));
                      element.click();
				//getDriver().findElement(By.xpath("/html[1]/body[1]/div[1]/div[7]/div[1]/div[3]/div[2]/form[1]/div[2]/table[1]/tbody[1]/tr[1]/td[2]/span[1]")).click();
				getDriver().findElement(By.xpath("//table[@id='datatable-new']/tbody/tr/td[3]/span")).click();
				}
			catch(Exception e) {}
				
			}
			try {Thread.sleep(2000);
			//	if(fluentWait(getDriver(), getDriver().findElement(By.xpath("//a[text()='View Portfolio']")), 10, 1))
				if (getDriver().findElement(By.xpath("//a[text()='View Portfolio']")).isDisplayed())
			{
				//	Thread.sleep(5000);
				writer.setCellData("Sheet-1", "PAN", crmMFincrement, reader.getCellData("Sheet1", "PAN", rowNum));
				System.out.println(reader.getCellData("Sheet1", "PAN", rowNum));
				++crmMFincrement;
					}}
			catch(Exception e) {}
		}
	}
	
	public boolean fluentWait(WebDriver driver,WebElement element,int timeoutMilliSec,int pollingTimeMilliSec) {
    	//Declare and initialise a fluent wait
    	FluentWait<WebDriver> wait = new FluentWait<WebDriver>( driver);
    	//Specify the timout of the wait
    	wait.withTimeout(Duration.ofMillis(timeoutMilliSec));
    	//Sepcify polling time
    	wait.pollingEvery(Duration.ofMillis(pollingTimeMilliSec));
    	//Specify what exceptions to ignore
    	wait.ignoring(NoSuchElementException.class);

    	//This is how we specify the condition to wait on.
    	//This is what we will explore more in this chapter
    	WebElement abc = wait.until(ExpectedConditions.visibilityOf(element));
  try {  if(abc.isDisplayed()) {
    	
    }
   }
  catch(Exception e) {
	  return false;
  }
  return true;
    
    }
	
}
