package com.qa.scripts;

import java.io.FileOutputStream;

import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import com.qa.base.TestBase;
import com.qa.util.Xls_Reader;

public class crmEwealth extends TestBase{
	
	//static Xls_Reader reader = new Xls_Reader(
		//	"D:\\Vrushali\\Projects\\Portfolio\\Script\\src\\main\\java\\com\\qa\\testdata\\WBR.xlsx");
	
	static Xls_Reader reader = new Xls_Reader("./src/main/java/com/qa/testdata/WBR.xlsx");
	static String username = "admin@financialhospital.in";
	static String password = "Happy2019#";

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		getDriver().findElement(By.xpath("//input[@name='EmailID']")).sendKeys(username);
		getDriver().findElement(By.xpath("//input[@name='Password']")).sendKeys(password);
		getDriver().findElement(By.xpath("//button[@name='loginbtn']")).click();
		Thread.sleep(8000);
		
		try {
			Workbook wb = new XSSFWorkbook();
			FileOutputStream fileout = new FileOutputStream("E:\\Asif\\Portfolios.xlsx");
			wb.write(fileout);
			fileout.close();
			//Xls_Reader writer = new Xls_Reader("E:\\Vrushali\\Portfolios.xlsx");
		}
		catch(Exception e) {
			e.printStackTrace();
		}

		int rowCount = reader.getRowCount("Sheet1");
		for (int rowNum = 2; rowNum <= rowCount; rowNum++) {
			getDriver().get("http://www.erokda.in/adminpanel/leads/viewsearchlead.php");
			Thread.sleep(10000);
			getDriver().findElement(By.xpath("//button[@name='filtershowbtn']")).click();
			Thread.sleep(2000);
			getDriver().findElement(By.xpath(
					"/html[1]/body[1]/div[1]/div[7]/div[1]/div[3]/form[1]/fieldset[1]/div[1]/div[2]/div[1]/div[2]/div[1]/span[1]/div[1]/button[1]"))
					.click();
			Thread.sleep(2000);
			getDriver().findElement(
					By.xpath("//div[@class='btn-group open']//li[@class='multiselect-item multiselect-all']//input"))
					.click();
			getDriver().findElement(By.xpath("//button[@name='searchbtn']")).click();
			Thread.sleep(5000);
			getDriver().findElement(By.xpath("//input[@placeholder='Search User']")).sendKeys(reader.getCellData("Sheet1", "PAN", rowNum));
			getDriver().findElement(By.xpath("//input[@placeholder='Search User']")).sendKeys(Keys.ENTER);
			
			
			

		}

	}

	

}
