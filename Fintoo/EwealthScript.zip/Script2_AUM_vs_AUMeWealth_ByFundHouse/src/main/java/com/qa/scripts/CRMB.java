package com.qa.scripts;

import java.io.FileOutputStream;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.poi.openxml4j.util.ZipSecureFile;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.qa.base.TestBase;
import com.qa.util.Xls_Reader;

public class CRMB extends TestBase{

	static int i;
	static int k;
	static int l;
	JavascriptExecutor js = (JavascriptExecutor) getDriver();
	//Xls_Reader reader = new Xls_Reader("./src/main/java/com/qa/testdata/WBR1.xlsx");
	Xls_Reader reader;
	//Xls_Reader reader01 = new Xls_Reader("D:\\Portfolios170.xlsx");
	String username = prop.getProperty("username");
	String password = prop.getProperty("password");
	String invDateCRM;
	String invDateEWealth;
	String unitsCRM;
	String unitsEWealth;
	String invCRM;
	String invEwealth;
	String curCRM,cAGRCRM,cAGREwealth;
	String curEwealth;
	Xls_Reader writer;
	String diffMFInvest,diffCurrent,diffCAGR,diffSubMFInvest,diffSubCurrent,diffSubCAGR,diffSubUnits;
	 String unitsSubHeaderEwealth;
		String investSubHeaderEwealth;
		String currentValueSubHeaderEwealth;
		String cAGRSubHeaderEwealth;
		String schemeNameSubHeaderCRM;
		String folioNoText;
		List<String> dateCrm;
		int dateincrement;
		int sizeScheme;
		int calculationIncrement=1;
		String schemeFistWord;
		String schemeSecondWord;
		List<String> folioNumberss;
		String schemeNoCRM01;
		int transactionsSize;
		int trans;
		int lastSchemeSize=0;
		int transactionSize;
		int a;
		String  dependPanNo,nextdependPanNo;
		int nextsizeScheme;
		//ArrayList<String> windowHandles1 ;
	/*
	 * String gainCRM; String gainEwealth;
	 * 
	 * String cagrCRM; String cagrEwealth;
	 */
	public CRMB() {
		PageFactory.initElements(getDriver(), this);
	}

	public void getData(String excelRead,String excelWrite) throws InterruptedException, java.io.IOException {
		//Xls_Reader reader = new Xls_Reader("./src/main/java/com/qa/testdata/WBR1.xlsx");
		 reader = new Xls_Reader(excelRead);
		getDriver().findElement(By.xpath("//input[@name='EmailID']")).sendKeys(username);
		getDriver().findElement(By.xpath("//input[@name='Password']")).sendKeys(password);
		getDriver().findElement(By.xpath("//button[@name='loginbtn']")).click();
		//Thread.sleep(8000);
		Workbook wb = new XSSFWorkbook();
		//FileOutputStream fileout = new FileOutputStream("D:\\Portfolios170.xlsx");
		FileOutputStream fileout = new FileOutputStream(excelWrite);
		ZipSecureFile.setMinInflateRatio(0);
		wb.write(fileout);
		fileout.close();
	    writer = new Xls_Reader(excelWrite);
		writer.addSheet("Sheet-1");
		writer.addColumn("Sheet-1", "PAN");
		writer.addColumn("Sheet-1", "MFInvestedHeaderValueCRM");
		writer.addColumn("Sheet-1", "MFCurrentHeaderValueCRM");
		writer.addColumn("Sheet-1", "MFCAGRHeadeCRM");
		writer.addColumn("Sheet-1", "MFInvestedHeaderValueEwealth");
		writer.addColumn("Sheet-1", "MFCurrentHeaderValueEwealth");
		writer.addColumn("Sheet-1", "MFCAGRHeadeEwealth");
		writer.addColumn("Sheet-1", "MFInvestedHeaderDifference");
		writer.addColumn("Sheet-1", "MFCurrentHeaderDifference");
		writer.addColumn("Sheet-1", "MFCAGRHeaderDifference");
		
		writer.addColumn("Sheet-1", "MFSubHeaderSchemeName");
		writer.addColumn("Sheet-1", "MFInvestedSubHeaderValueCRM");
		writer.addColumn("Sheet-1", "MFCurrentSubHeaderValueCRM");
		writer.addColumn("Sheet-1", "MFCAGRSubHeadeCRM");
		writer.addColumn("Sheet-1", "MFUnitsSubHeadeCRM");
		writer.addColumn("Sheet-1", "MFInvestedSubHeaderValueEwealth");
		writer.addColumn("Sheet-1", "MFCurrentSubHeaderValueEwealth");
		writer.addColumn("Sheet-1", "MFCAGRSubHeadeEwealth");
		writer.addColumn("Sheet-1", "MFUnitsSubHeadeEwealth");
		writer.addColumn("Sheet-1", "MFInvestedSubHeaderDifference");
		writer.addColumn("Sheet-1", "MFCurrentSubHeaderDifference");
		writer.addColumn("Sheet-1", "MFCAGRSubHeaderDifference");
		writer.addColumn("Sheet-1", "MFUnitsSubHeaderDifference");
	
		writer.addColumn("Sheet-1", "Scheme Name CRM");
		writer.addColumn("Sheet-1", "Folio No");
		writer.addColumn("Sheet-1", "Invested Date CRM");
		writer.addColumn("Sheet-1", "Units CRM");
		writer.addColumn("Sheet-1", "Invested Val CRM");
		writer.addColumn("Sheet-1", "Current Val CRM");
		writer.addColumn("Sheet-1", "CAGR CRM");
		
		writer.addColumn("Sheet-1", "Scheme NAme eWealth");
		writer.addColumn("Sheet-1", "Invested Date eWealth");
		writer.addColumn("Sheet-1", "Units eWealth");
		writer.addColumn("Sheet-1", "Invested Val eWealth");
		writer.addColumn("Sheet-1", "Current Val eWealth");
		writer.addColumn("Sheet-1", "CAGR eWealth");
		//writer.addColumn("Sheet-1", "Difference in Dates");
		writer.addColumn("Sheet-1", "Difference in Units");
		writer.addColumn("Sheet-1", "Difference in Invested Val");
		writer.addColumn("Sheet-1", "Difference in Current Val");
		writer.addColumn("Sheet-1", "Difference in CAGR");
		
		getDriver().get("http://www.financialhospital.in/adminpanel/leads/viewsearchlead.php");
		//Thread.sleep(8000);//
		getDriver().findElement(By.xpath("//button[@id='btn-show-reco-filter']")).click();
	//	Thread.sleep(2000);
		getDriver().findElement(By.xpath("/html[1]/body[1]/div[1]/div[7]/div[1]/div[2]/div[2]/form[1]/fieldset[1]/div[1]/div[2]/div[1]/div[2]/div[1]/span[1]/div[1]/button[1]"))
				.click();
	//	Thread.sleep(5000);
		getDriver().findElement(By.xpath("//div[@class='btn-group open']//li[@class='multiselect-item multiselect-all']//input"))
				.click();
		getDriver().findElement(By.xpath("//button[@name='searchbtn']")).click();
		Thread.sleep(5000);
		int crmMFincrement = 2;
		int rowIncrement = 2;
		int rowCount = reader.getRowCount("Sheet1");
	//	int rowsize = 10 * rowCount;
	//	dateCrm =new ArrayList<String>();
		for (int rowNum = 1; rowNum < rowCount; rowNum++) { 
			try {
			writer.setCellData("Sheet-1", "PAN", crmMFincrement, reader.getCellData("Sheet1", "PAN", rowNum));
			System.out.println(reader.getCellData("Sheet1", "PAN", rowNum));
			headerValue(rowNum, crmMFincrement);
			if(!diffMFInvest.equals("0.0") || !diffCurrent.equals("0.0")||!diffCAGR.equals("0.0")) {
               for( a=1;a<=transactionSize;a++) {
            	   if(a>=2) {
           			writer.setCellData("Sheet-1", "PAN", crmMFincrement, dependPanNo);
           		}
            	   
				for( i=1;i<=sizeScheme;i++) {
                 subHeaderValue(rowNum, i, crmMFincrement);
              //   if(!diffSubMFInvest.equals("0.0") || !diffSubCurrent.equals("0.0")||!diffSubCAGR.equals("0.0") ||!diffSubUnits.equals("0.0")) 
                 if(!diffSubUnits.equals("0.0")){ 
			try {
				dateCrm =new ArrayList<String>();
				getDriver().get("http://www.financialhospital.in/adminpanel/leads/viewsearchlead.php");
				Thread.sleep(3000);//
				getDriver().findElement(By.xpath("//input[@type='search']"))
						.sendKeys(reader.getCellData("Sheet1", "PAN", rowNum));
				getDriver().findElement(By.xpath("//input[@type='search']")).sendKeys(Keys.ENTER);
				
				Thread.sleep(8000);
				if (getDriver().findElement(By.xpath(
						"/html[1]/body[1]/div[1]/div[7]/div[1]/div[3]/div[2]/form[1]/div[2]/table[1]/tbody[1]/tr[1]/td[2]/span[1]")) != null) {
					getDriver().findElement(By.xpath("//table[@id='datatable-new']/tbody/tr/td[3]/span")).click();
					//Thread.sleep(5000);
					try {
						 Thread.sleep(5000);
						if (getDriver()
								.findElement(
										By.xpath("//*[@id='datatable-new']/tbody/tr[2]/td/table/tbody/tr/td[10]/a"))
								.isDisplayed()) {
						//	Thread.sleep(5000);
							String url2 = getDriver()
									.findElement(
											By.xpath("//*[@id='datatable-new']/tbody/tr[2]/td/table/tbody/tr/td[10]/a"))
									.getAttribute("href");
							getDriver().get(url2);
						//	Thread.sleep(5000);//
																					
							// newly added
							getDriver().findElement(By.xpath("//div//div//div//li[2]//a[1]")).click();
							//Thread.sleep(5000);
//							getDriver().findElement(
//									By.xpath("//body/div/div/div/div/div/div/div/div/div[3]/div[1]/div[1]/a[1]"))
//									.click();
							
							getDriver().findElement(By.xpath("(//a[@data-toggle='collapse'])["+(a+a-1)+"]")).click();
						//	Thread.sleep(5000);
							js.executeScript("window.scrollBy(0,200)");
							int scriptCount = getDriver().findElements(By.xpath("//td[@style='padding:0']")).size();
							int Scriptsize = scriptCount * 2;
						//	for (i = 1; i <= Scriptsize; i++) {
								try {
									Thread.sleep(3000);
								//	WebElement SchemeNameElement = getDriver().findElement(By.xpath("(//a[@style='cursor: pointer;'])[" + i + "]"));
									WebElement SchemeNameElement = getDriver().findElement(By.xpath("/html/body/div[2]/div[7]/div/div/div/div/div[1]/div/div["+(3*a)+"]/div[2]/div/div[2]/div/div[2]/div/div[4]/div/div[1]/table/tbody/tr["+(i+i-1)+"]/td[1]/table/tbody/tr/td"));
									
									
									String SchemeName = SchemeNameElement.getText();
									System.out.println(SchemeName);
									Thread.sleep(2000);
									String schemeNoCRMElement = getDriver().findElement(By.xpath("/html/body/div[2]/div[7]/div/div/div/div/div[1]/div/div["+(3*a)+"]/div[2]/div/div[2]/div/div[2]/div/div[4]/div/div[1]/table/tbody/tr["+(i+(i-1))+"]")).getAttribute("id");
									System.out.println(schemeNoCRMElement);
									String[] schemeNoCRMElementArray = schemeNoCRMElement.split("_");
									String schemeNOCRMComplete = schemeNoCRMElementArray[1];
									 schemeNoCRM01=schemeNOCRMComplete.substring(0,7);									
									
									//WebElement folioNoElement = getDriver().findElement(By.xpath("(//td[contains(.,'Folio')])[" + (i + i) + "]"));
									 WebElement folioNoElement = getDriver().findElement(By.xpath("/html/body/div[2]/div[7]/div/div/div/div/div[1]/div/div["+(3*a)+"]/div[2]/div/div[2]/div/div[2]/div/div[4]/div/div[1]/table/tbody/tr["+(i+(i-1))+"]/td[1]/table/tbody/tr/td"));
									
									String[] folioNoArray = folioNoElement.getText().split(":");
									String[] schemeNameArray=folioNoElement.getText().split(" ");
									 schemeFistWord=schemeNameArray[0].toLowerCase();
									 schemeSecondWord=schemeNameArray[1].toLowerCase();
									 folioNoText = folioNoArray[1].trim();
									//  folioNumberss= new ArrayList<String>();
									 //folioNumberss.add(folioNoText);
									writer.setCellData("Sheet-1", "Scheme Name CRM", crmMFincrement, SchemeName);
									writer.setCellData("Sheet-1", "Folio No", crmMFincrement, folioNoText);
									//getDriver().findElement(By.xpath("(//a[@style='cursor: pointer;'])[" + i + "]")).click();
									getDriver().findElement(By.xpath("/html/body/div[2]/div[7]/div/div/div/div/div[1]/div/div["+(a*3)+"]/div[2]/div/div[2]/div/div[2]/div/div[4]/div/div[1]/table/tbody/tr["+(i+i-1)+"]/td[1]/table/tbody/tr/td/a")).click();
									// SchemeNameElement.click();
									//(//table[@class='responsivetable responsivetable3'])[2]/tbody
									//int sizeSubHeaderSchemeCRM=getDriver().findElements(By.xpath("(//table[@class='responsivetable responsivetable3'])["+(i+i)+"]/tbody")).size();
									int sizeSubHeaderSchemeCRM=getDriver().findElements(By.xpath("/html/body/div[2]/div[7]/div/div/div/div/div[1]/div/div["+(a*3)+"]/div[2]/div/div[2]/div/div[2]/div/div[4]/div/div[1]/table/tbody/tr["+(i+i)+"]/td/div/table/tbody")).size();
									try {
										for (int x = 1; x <= sizeSubHeaderSchemeCRM; x++) {
											String investmentDateCRM = getDriver().findElement(By.xpath(
													"/html[1]/body[1]/div[2]/div[7]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div["+(3*a)+"]/div[2]/div[1]/div[2]/div[1]/div[2]/div[1]/div[4]/div[1]/div[1]/table[1]/tbody[1]/tr["
															+ (i + i) + "]/td[1]/div[1]/table[1]/tbody[" + x
															+ "]/tr[1]/td[3]"))
													.getText();
											String amountCRM = getDriver().findElement(By.xpath(
													"/html[1]/body[1]/div[2]/div[7]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div["+(3*a)+"]/div[2]/div[1]/div[2]/div[1]/div[2]/div[1]/div[4]/div[1]/div[1]/table[1]/tbody[1]/tr["
															+ (i + i) + "]/td[1]/div[1]/table[1]/tbody[" + x
															+ "]/tr[1]/td[4]"))
													.getText().replaceAll(",", "");
											String unitsCRM = getDriver().findElement(By.xpath(
													"/html[1]/body[1]/div[2]/div[7]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div["+(3*a)+"]/div[2]/div[1]/div[2]/div[1]/div[2]/div[1]/div[4]/div[1]/div[1]/table[1]/tbody[1]/tr["
															+ (i + i) + "]/td[1]/div[1]/table[1]/tbody[" + x
															+ "]/tr[1]/td[6]"))
													.getText();
											String curValueCRM = getDriver().findElement(By.xpath(
													"/html[1]/body[1]/div[2]/div[7]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div["+(3*a)+"]/div[2]/div[1]/div[2]/div[1]/div[2]/div[1]/div[4]/div[1]/div[1]/table[1]/tbody[1]/tr["
															+ (i + i) + "]/td[1]/div[1]/table[1]/tbody[" + x
															+ "]/tr[1]/td[9]"))
													.getText().replaceAll(",", "");
											
											String cagrCRM = getDriver().findElement(By.xpath(
													"/html[1]/body[1]/div[2]/div[7]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div["+(3*a)+"]/div[2]/div[1]/div[2]/div[1]/div[2]/div[1]/div[4]/div[1]/div[1]/table[1]/tbody[1]/tr["
															+ (i + i) + "]/td[1]/div[1]/table[1]/tbody[" + x
															+ "]/tr[1]/td[12]"))
													.getText().replaceAll(",", "");
											// Thread.sleep(3000);
											
											dateCrm.add(investmentDateCRM);
											writer.setCellData("Sheet-1", "Invested Date CRM", crmMFincrement,
													investmentDateCRM);
											writer.setCellData("Sheet-1", "Invested Val CRM", crmMFincrement,
													amountCRM);
											// Thread.sleep(3000);
											writer.setCellData("Sheet-1", "Units CRM", crmMFincrement, unitsCRM);
											writer.setCellData("Sheet-1", "Current Val CRM", crmMFincrement,
													curValueCRM);
											writer.setCellData("Sheet-1", "CAGR CRM", crmMFincrement,
													cagrCRM);
											++crmMFincrement;

										}
									} catch (Exception e) {
										getDriver().findElement(By.xpath("(//a[@style='cursor: pointer;'])[" + i + "]"))
												.click();
									}
									
									// ++crmMFincrement;
								} catch (Exception e) {
								}

							//}

						} else {
							System.out
									.println("email id not available : " + reader.getCellData("Sheet1", "PAN", rowNum));
						}

					} catch (Exception e) {
						System.out.println("DATA Not available in CRM" + reader.getCellData("Sheet1", "PAN", rowNum));
						;
					}
				}
				
				++crmMFincrement;
			} catch (Exception e) {
				System.out.println("DATA Not available in CRM " + reader.getCellData("Sheet1", "PAN", rowNum));
			}
			// eWealth

			//Thread.sleep(3000);
			getDriver().get("https://www.financialhospital.in/adminpanel/Index.php");
		//	Thread.sleep(5000);
			getDriver().findElement(By
					.xpath("/html[1]/body[1]/div[2]/div[3]/div[1]/div[2]/div[2]/form[1]/div[1]/div[2]/h1[1]/input[1]"))
					.click();
		//	Thread.sleep(7000);
			ArrayList<String> windowHandles = new ArrayList<String>(getDriver().getWindowHandles());
			getDriver().switchTo().window(windowHandles.get(1));

		//	Thread.sleep(5000);

			//getDriver().findElement(By.xpath("//div/a[contains(text(),'Reports')]")).click();
			getDriver().findElement(By.xpath("/html/body/div[9]/div[2]/div[2]/div[12]/a")).click();
			js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
			Select viewBy = new Select(getDriver().findElement(By.id("view")));
			viewBy.selectByVisibleText("Clients");
			if(a>=2) 
			{
				getDriver().findElement(By.id("srch")).sendKeys(dependPanNo);
			}
			else {
			getDriver().findElement(By.id("srch")).sendKeys(reader.getCellData("Sheet1", "PAN", rowNum));}
			//Thread.sleep(3000);

			String text = "No Record Found";
			Thread.sleep(4000);
			if (getDriver().findElement(By.xpath("//html[1]/body[1]/div[5]/ul[1]/li[1]")).getText().equals(text)) {
				try {
					System.out.println("Pan not found : " + reader.getCellData("Sheet1", "PAN", rowNum));
					ArrayList<String> windowHandles2 = new ArrayList<String>(getDriver().getWindowHandles());
					getDriver().close();
					getDriver().switchTo().window(windowHandles2.get(0));
				} catch (Exception e) {
					System.out.println("record not found : " + reader.getCellData("Sheet1", "PAN", rowNum));
				}
			} else {
				//Thread.sleep(3000);

				// getDriver().findElement(By.xpath("//*[@id='srch_opt2']")).click();
				getDriver().findElement(By.xpath("//form[@id='select_Client']")).click();
				getDriver().findElement(By.xpath("/html[1]/body[1]/div[5]/ul[1]/li[1]")).click();
				getDriver().findElement(By.xpath(
						"/html[1]/body[1]/div[2]/div[3]/div[3]/dl[1]/dd[1]/form[1]/center[1]/table[1]/tbody[1]/tr[12]/td[1]/div[1]/input[1]"))
						.click();

				ArrayList<String> windowHandles1 = new ArrayList<String>(getDriver().getWindowHandles());
				getDriver().switchTo().window(windowHandles1.get(2));
			//	Thread.sleep(3000);
				getDriver().findElement(
						By.xpath("/html[1]/body[1]/div[1]/div[1]/div[2]/table[2]/tbody[1]/tr[2]/td[1]/div[1]/div[1]"))
						.click();
				js.executeScript("window.scrollBy(0,200)");

				
				int scriptsizeEwealth = getDriver().findElements(By.xpath("//tr[@class='graw-bg']")).size();
				for (k = 1; k <= scriptsizeEwealth; k++) {
					Thread.sleep(4000);
					String schemeNoEwealthElement = getDriver().findElement(By.xpath("/html/body/div/div/div[2]/div[4]/section/div/div/div[1]/div/div/div/table/tbody/tr["+(k+(k-1))+"]")).getAttribute("id");
					System.out.println(schemeNoEwealthElement);
					String[] schemeNoEwealthElementArray = schemeNoEwealthElement.split("_");
					String schemeNoEwealth01 = schemeNoEwealthElementArray[2];
					WebElement schemNameEwealth = getDriver().findElement(By.xpath("(//td[@id='flip'])[" + k + "]"));
			  String[] schemeEwealthNameArray=	schemNameEwealth.getText().split(" ");
			        String  schemeEwealthFirstWord= schemeEwealthNameArray[0].toLowerCase();
			        String  schemeEwealthSecondWord= schemeEwealthNameArray[1].toLowerCase();
					String folioNumberEwealth=schemNameEwealth.getText().split(":")[1].trim();
					String folioNumText=folioNumberEwealth.split(" ")[0];
				//	Set<String> foliono = duplicatevalue(folioNumberss);
					
			
					
					 
					if(schemeNoCRM01.contains(schemeNoEwealth01) && folioNoText.equals(folioNumText)) 
					{
					String schemeNameEwealthText = schemNameEwealth.getText();
					schemNameEwealth.click();
					writer.setCellData("Sheet-1", "Scheme NAme eWealth", rowIncrement, schemeNameEwealthText);
					Thread.sleep(3000);
					try {
						if (getDriver().findElement(By.xpath("(//a[text()='Show All Transaction'])["+k+"]")).isDisplayed()) {
							getDriver().findElement(By.xpath("(//a[text()='Show All Transaction'])["+k+"]")).click();
						}
					} catch (Exception e) {
					}
                     Thread.sleep(4000);
					int sizeSchemeEwealth=getDriver().findElements(By.xpath("(//tbody[@class='f-10'])["+k+"]/tr")).size();
					try {

						for (int m = 1; m <= sizeSchemeEwealth; m++) {

							// schemeNameEwealth.click();
							String investmentDateEwealth = getDriver().findElement(By.xpath(
									"/html/body/div/div/div[2]/div[4]/section/div/div/div[1]/div/div/div/table/tbody/tr["
											+ (k + k) + "]/td/div[2]/table/tbody/tr[" + m + "]/td[3]"))
									.getText();

							String amountEwealth = getDriver().findElement(By.xpath(
									"/html/body/div/div/div[2]/div[4]/section/div/div/div[1]/div/div/div/table/tbody/tr["
											+ (k + k) + "]/td/div[2]/table/tbody/tr[" + m + "]/td[4]"))
									.getText().replaceAll(",", "");

							String unitsEwealth = getDriver().findElement(By.xpath(
									"/html/body/div/div/div[2]/div[4]/section/div/div/div[1]/div/div/div/table/tbody/tr["
											+ (k + k) + "]/td/div[2]/table/tbody/tr[" + m + "]/td[6]"))
									.getText();

							String curValueEwealth = getDriver().findElement(By.xpath(
									"/html/body/div/div/div[2]/div[4]/section/div/div/div[1]/div/div/div/table/tbody/tr["
											+ (k + k) + "]/td/div[2]/table/tbody/tr[" + m + "]/td[9]"))
									.getText().replaceAll(",", "");
							
							String cagrEwealth = getDriver().findElement(By.xpath(
									"/html/body/div/div/div[2]/div[4]/section/div/div/div[1]/div/div/div/table/tbody/tr["
											+ (k + k) + "]/td/div[2]/table/tbody/tr[" + m + "]/td[14]"))
									.getText().replaceAll("%", "");
							
							int aa=0;

							for(int dateincrement=0;dateincrement<dateCrm.size();dateincrement++) {
								
								
							if((investmentDateEwealth.contains(dateCrm.get(dateincrement).toString()))) {	
//								if(aa>=m) {
//									rowIncrement=rowIncrement+(aa);
//								}
								rowIncrement=rowIncrement+(aa);
								
							writer.setCellData("Sheet-1", "Invested Date eWealth", rowIncrement, investmentDateEwealth);
							writer.setCellData("Sheet-1", "Units eWealth", rowIncrement, unitsEwealth);
							writer.setCellData("Sheet-1", "Invested Val eWealth", rowIncrement, amountEwealth);
							writer.setCellData("Sheet-1", "Current Val eWealth", rowIncrement, curValueEwealth);
							writer.setCellData("Sheet-1", "CAGR eWealth", rowIncrement, cagrEwealth);
//							if(aa>=m) {
//								rowIncrement=rowIncrement-(aa+1);
//							}
							rowIncrement=rowIncrement-(aa+1);
							
							break;
							
							}
							else {
								++aa;}
							
							}
							if(aa==dateCrm.size()) {
								--rowIncrement;
								writer.setCellData("Sheet-1", "Invested Date eWealth", crmMFincrement, investmentDateEwealth);
								writer.setCellData("Sheet-1", "Units eWealth", crmMFincrement, unitsEwealth);
								writer.setCellData("Sheet-1", "Invested Val eWealth", crmMFincrement, amountEwealth);
								writer.setCellData("Sheet-1", "Current Val eWealth", crmMFincrement, curValueEwealth);
								++crmMFincrement;
								
							}
							
							++rowIncrement;
						}

						++rowIncrement;
						} catch (Exception e) {

						schemNameEwealth.click();
					}
					if(crmMFincrement>rowIncrement) {
						rowIncrement=crmMFincrement;
					}
					if(rowIncrement>crmMFincrement) {
						crmMFincrement=rowIncrement;
					}
					break;

				}}

				getDriver().close();
				getDriver().switchTo().window(windowHandles1.get(1));
				getDriver().close();
				getDriver().switchTo().window(windowHandles1.get(0));
			}
			}
                 else {
                	 rowIncrement++;
                	 rowIncrement++;
                	 crmMFincrement++;
                	 crmMFincrement++;
                 }  
              if(i== lastSchemeSize) {
            	 try { lastSchemeSize=sizeScheme;
            	  break;}
            	 catch (Exception e) {}
              }   
				
				}
				if(sizeScheme==0) {
					sizeScheme=nextsizeScheme;
					writer.setCellData("Sheet-1", "PAN", crmMFincrement, dependPanNo);
					dependPanNo=nextdependPanNo;
					writer.setCellData("Sheet-1", "MFInvestedHeaderValueCRM", crmMFincrement, "No transaction");
					rowIncrement++;
               	 rowIncrement++;
               	 crmMFincrement++;
               	 crmMFincrement++;
               	 a++;
				}}
				}
			
		}			
		catch(Exception e) {
			e.printStackTrace();
			ArrayList<String> windowHandles1 = new ArrayList<String>(getDriver().getWindowHandles());
			int windowSize=windowHandles1.size();
			
			if(windowSize==3) {
			getDriver().close();
			getDriver().switchTo().window(windowHandles1.get(1));
			getDriver().close();
			getDriver().switchTo().window(windowHandles1.get(0));}
			else if(windowSize==2) {
				try {
				getDriver().switchTo().alert().accept();}
				catch(Exception b) {}
				getDriver().close();
				getDriver().switchTo().window(windowHandles1.get(0));
			}
			
			System.out.println("No portfolio Available:"+" "+reader.getCellData("Sheet1", "PAN", rowNum));
			writer.setCellData("Sheet-1", "MFInvestedHeaderValueCRM", crmMFincrement, "No Portfolio");
			rowIncrement++;
       	 rowIncrement++;
       	 crmMFincrement++;
       	 crmMFincrement++;
       	if(crmMFincrement>rowIncrement) {
			rowIncrement=crmMFincrement;
		}
		if(rowIncrement>crmMFincrement) {
			crmMFincrement=rowIncrement;
		}
		}
			}
		int lastRowNum = writer.getRowCount("Sheet-1");
		int LastCellNum = writer.getColumnCount("Sheet-1");
	for(int calculationIncrement=1;calculationIncrement<lastRowNum;calculationIncrement++) { 
		invCRM = writer.getCellData("Sheet-1", "Invested Val CRM", calculationIncrement).replaceAll(",", "");
		invEwealth = writer.getCellData("Sheet-1", "Invested Val eWealth", calculationIncrement).replaceAll(",", "");
		//invDateCRM = writer.getCellData("Sheet-1", 3, s);
		//invDateEWealth = writer.getCellData("Sheet-1", 8, s);
		unitsCRM = writer.getCellData("Sheet-1", "Units CRM", calculationIncrement).replaceAll(",", "");
		unitsEWealth = writer.getCellData("Sheet-1", "Units eWealth", calculationIncrement).replaceAll(",", "");
		curCRM = writer.getCellData("Sheet-1", "Current Val CRM", calculationIncrement).replaceAll(",", "");
		curEwealth = writer.getCellData("Sheet-1", "Current Val eWealth", calculationIncrement).replaceAll(",", "");
		cAGRCRM = writer.getCellData("Sheet-1", "CAGR CRM", calculationIncrement).replaceAll(",", "");
		cAGREwealth = writer.getCellData("Sheet-1", "CAGR eWealth", calculationIncrement).replaceAll(",", "");
		//++calculationIncrement;
		try {
		if(!(invCRM==null || invEwealth==null || unitsCRM==null || unitsEWealth==null|| curCRM==null || curEwealth==null)) {
		if (!(unitsCRM.equals(unitsEWealth))) {
			double unitCrm = Double.parseDouble(unitsCRM);
			double unitEwealth = Double.parseDouble(unitsEWealth);
			double unitsDifference = unitCrm - unitEwealth;
			String unitdiff = new DecimalFormat("##.####").format(unitsDifference);
			// String unitdiff= String.valueOf(unitsDifference);

			writer.setCellData("Sheet-1", "Difference in Units", calculationIncrement+1, unitdiff);
		}

		if (!(invCRM.equals(invEwealth))) {
			double invCrm = Double.parseDouble(invCRM);
			double invewealth = Double.parseDouble(invEwealth);
			double invDifference = invCrm - invewealth;
			String invdiff = new DecimalFormat("##.####").format(invDifference);
			// String invdiff= String.valueOf(unitsDifference);

			writer.setCellData("Sheet-1", "Difference in Invested Val", calculationIncrement+1, invdiff);
		}

		if (!(curCRM.equals(curEwealth))) {

			double curCrm = Double.parseDouble(curCRM);
			double curewealth = Double.parseDouble(curEwealth);
			double curDifference = curCrm - curewealth;
			String curdiff = new DecimalFormat("##.####").format(curDifference);
			// String invdiff= String.valueOf(curDifference);

			writer.setCellData("Sheet-1", "Difference in Current Val", calculationIncrement+1, curdiff);
		}

		if (!(cAGRCRM.equals(cAGREwealth))) {

			double cagrCrm = Double.parseDouble(cAGRCRM);
			double cagrewealth = Double.parseDouble(cAGREwealth);
			double cagrDifference = cagrCrm - cagrewealth;
			String cagrdiff = new DecimalFormat("##.####").format(cagrDifference);
			// String invdiff= String.valueOf(curDifference);

			writer.setCellData("Sheet-1", "Difference in CAGR", calculationIncrement+1, cagrdiff);
		}
		
	}
		}
		catch(Exception e) {
			writer.setCellData("Sheet-1", "Difference in Current Val", calculationIncrement+1);
			writer.setCellData("Sheet-1", "Difference in Units", calculationIncrement+1);
			writer.setCellData("Sheet-1", "Difference in Invested Val", calculationIncrement+1);
			writer.setCellData("Sheet-1", "Difference in CAGR", calculationIncrement+1);
		}
		}

		
		

	}
	public void headerValue(int rowNumber, int crmMFincrement01) throws InterruptedException {
		getDriver().get("http://www.financialhospital.in/adminpanel/leads/viewsearchlead.php");
		//Thread.sleep(6000);//
		getDriver().findElement(By.xpath("//input[@type='search']"))
				.sendKeys(reader.getCellData("Sheet1", "PAN", rowNumber));
		getDriver().findElement(By.xpath("//input[@type='search']")).sendKeys(Keys.ENTER);
		
		//Thread.sleep(8000);
		if (getDriver().findElement(By.xpath(
				"/html[1]/body[1]/div[1]/div[7]/div[1]/div[3]/div[2]/form[1]/div[2]/table[1]/tbody[1]/tr[1]/td[2]/span[1]")) != null) {
				Thread.sleep(3000);	
				
			try {
				Thread.sleep(10000);
				
			//	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//table[@id='datatable-new']/tbody/tr/td[6]")));

			getDriver().findElement(By.xpath("/html[1]/body[1]/div[1]/div[7]/div[1]/div[3]/div[2]/form[1]/div[2]/table[1]/tbody[1]/tr[1]/td[2]/span[1]")).click();
			getDriver().findElement(By.xpath("//table[@id='datatable-new']/tbody/tr/td[3]/span")).click();
					}
		catch(Exception e) {}
			
		}
			Thread.sleep(5000);
		if (getDriver().findElement(By.xpath("//a[text()='View Portfolio']")).isDisplayed())
		{
		
		//	Thread.sleep(5000);
			String url2 = getDriver().findElement(By.xpath("//a[text()='View Portfolio']")).getAttribute("href");
			getDriver().get(url2);
			}
		
		
		
		
		String mfInvestValHeaderCRM = getDriver().findElement(By.xpath("(//span[@class='font20 customFont'])[1]")).getText().replaceAll("[₹ ,]", "");
		String mfCurrentValHeaderCRM = getDriver().findElement(By.xpath("(//span[@class='font20 customFont'])[2]")).getText().replaceAll("[₹ ,]", "");
		String mfCAGRValHeaderCRM = getDriver().findElement(By.xpath("(//span[@class='font20 customFont'])[4]")).getText().replaceAll("%", "");
		
		getDriver().findElement(By.xpath("//span[text()='MF Transactions ']")).click();
		//Thread.sleep(3000);
		getDriver().findElement(By.xpath("(//a[@data-toggle='collapse'])[1]")).click();
		//sizeScheme=getDriver().findElements(By.xpath("//td[@style='padding:0']")).size();
		sizeScheme=(getDriver().findElements(By.xpath("/html/body/div[2]/div[7]/div/div/div/div/div[1]/div/div[3]/div[2]/div/div[2]/div/div[2]/div/div[4]/div/div[1]/table/tbody/tr")).size())/2;
		 transactionSize= (getDriver().findElements(By.xpath("//a[contains(text(),'TRANSACTIONS')]")).size())/2;
		
		
		getDriver().get("https://www.financialhospital.in/adminpanel/Index.php");
		//Thread.sleep(5000);
		getDriver().findElement(By
				.xpath("/html[1]/body[1]/div[2]/div[3]/div[1]/div[2]/div[2]/form[1]/div[1]/div[2]/h1[1]/input[1]"))
				.click();
	//	Thread.sleep(7000);
		ArrayList<String> windowHandles = new ArrayList<String>(getDriver().getWindowHandles());
		getDriver().switchTo().window(windowHandles.get(1));

		//Thread.sleep(5000);

		getDriver().findElement(By.xpath("//div/a[contains(text(),'Reports')]")).click();
		js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
		Select viewBy = new Select(getDriver().findElement(By.id("view")));
		viewBy.selectByVisibleText("Clients");
		getDriver().findElement(By.id("srch")).sendKeys(reader.getCellData("Sheet1", "PAN", rowNumber));
		Thread.sleep(4000);//
		getDriver().findElement(By.xpath("//form[@id='select_Client']")).click();
		getDriver().findElement(By.xpath("/html[1]/body[1]/div[5]/ul[1]/li[1]")).click();
		getDriver().findElement(By.xpath(
				"/html[1]/body[1]/div[2]/div[3]/div[3]/dl[1]/dd[1]/form[1]/center[1]/table[1]/tbody[1]/tr[12]/td[1]/div[1]/input[1]"))
				.click();
		ArrayList<String> windowHandles1 = new ArrayList<String>(getDriver().getWindowHandles());
		getDriver().switchTo().window(windowHandles1.get(2));
		//Thread.sleep(3000);
		getDriver().findElement(
				By.xpath("/html[1]/body[1]/div[1]/div[1]/div[2]/table[2]/tbody[1]/tr[2]/td[1]/div[1]/div[1]"))
				.click();
		js.executeScript("window.scrollBy(0,200)");
		String mfInvestValHeaderEwealth = getDriver().findElement(By.xpath("//div[@id='mf_button']/following::div[1]")).getText().replaceAll(",", "");
		String mfCurrentValHeaderEwealth = getDriver().findElement(By.xpath("//div[@id='mf_button']/following::div[2]")).getText().replaceAll(",", "");
		String mfCAGRValHeaderEwealth = getDriver().findElement(By.xpath("//div[@id='mf_button']/following::div[4]")).getText().replaceAll("%", "");

		writer.setCellData("Sheet-1", "MFInvestedHeaderValueCRM", crmMFincrement01, mfInvestValHeaderCRM);
		writer.setCellData("Sheet-1", "MFCurrentHeaderValueCRM", crmMFincrement01, mfCurrentValHeaderCRM);
		writer.setCellData("Sheet-1", "MFCAGRHeadeCRM", crmMFincrement01, mfCAGRValHeaderCRM);
		writer.setCellData("Sheet-1", "MFInvestedHeaderValueEwealth", crmMFincrement01, mfInvestValHeaderEwealth);
		writer.setCellData("Sheet-1", "MFCurrentHeaderValueEwealth", crmMFincrement01, mfCurrentValHeaderEwealth);
		writer.setCellData("Sheet-1", "MFCAGRHeadeEwealth", crmMFincrement01, mfCAGRValHeaderEwealth);
		
		double mfInvestValCRM=Double.parseDouble(mfInvestValHeaderCRM);
		double mfCurrentValCRM =Double.parseDouble(mfCurrentValHeaderCRM);
		double mfCAGRCRM =Double.parseDouble(mfCAGRValHeaderCRM);
		double investEwealth=Double.parseDouble(mfInvestValHeaderEwealth);
		double currentEwealth=Double.parseDouble(mfCurrentValHeaderEwealth);
		double mfCAGREwealth=Double.parseDouble(mfCAGRValHeaderEwealth);
		 diffMFInvest =Double.toString(mfInvestValCRM-investEwealth);
		 diffCurrent=Double.toString(mfCurrentValCRM-currentEwealth);
		 diffCAGR= Double.toString(mfCAGRCRM-mfCAGREwealth);
		
		writer.setCellData("Sheet-1", "MFInvestedHeaderDifference", crmMFincrement01, diffMFInvest);
		writer.setCellData("Sheet-1", "MFCurrentHeaderDifference", crmMFincrement01, diffCurrent);
		writer.setCellData("Sheet-1", "MFCAGRHeaderDifference", crmMFincrement01, diffCAGR);
		getDriver().close();
		getDriver().switchTo().window(windowHandles1.get(1));
		getDriver().close();
		getDriver().switchTo().window(windowHandles1.get(0));
	}

	public void subHeaderValue(int rowNumber,int schemeNum,int crmMFincrement01) throws InterruptedException {
		getDriver().get("http://www.financialhospital.in/adminpanel/leads/viewsearchlead.php");
	//	Thread.sleep(6000);
//		if(a>=2) {
//			writer.setCellData("Sheet-1", "PAN", crmMFincrement01, dependPanNo);
//		}
		
		getDriver().findElement(By.xpath("//input[@type='search']"))
				.sendKeys(reader.getCellData("Sheet1", "PAN", rowNumber));
		getDriver().findElement(By.xpath("//input[@type='search']")).sendKeys(Keys.ENTER);
		//Thread.sleep(4000);
		if (getDriver().findElement(By.xpath(
				"/html[1]/body[1]/div[1]/div[7]/div[1]/div[3]/div[2]/form[1]/div[2]/table[1]/tbody[1]/tr[1]/td[2]/span[1]")) != null) {
						
			int attempts = 0;
		    while(attempts < 2) {
		        try {Thread.sleep(10000);
		        	getDriver().findElement(By.xpath("/html[1]/body[1]/div[1]/div[7]/div[1]/div[3]/div[2]/form[1]/div[2]/table[1]/tbody[1]/tr[1]/td[2]/span[1]")).click();
					getDriver().findElement(By.xpath("//table[@id='datatable-new']/tbody/tr/td[3]/span")).click();
				
		            break;
		        } catch(Exception e) {
		        }
		        attempts++;
		    }
		}
		Thread.sleep(9000);
				String url2 = getDriver().findElement(By.xpath("//a[text()='View Portfolio']")).getAttribute("href");
			getDriver().get(url2);
		
		getDriver().findElement(By.xpath("//span[text()='MF Transactions ']")).click();
		getDriver().findElement(By.xpath("(//a[@data-toggle='collapse'])["+(a+a-1)+"]")).click();
		
		if(sizeScheme==schemeNum) {
			try {
			 lastSchemeSize=sizeScheme;
			sizeScheme=(getDriver().findElements(By.xpath("/html/body/div[2]/div[7]/div/div/div/div/div[1]/div/div["+((a+1)*3)+"]/div[2]/div/div[2]/div/div[2]/div/div[4]/div/div[1]/table/tbody/tr")).size())/2;
		String[]  dependantPanNo= getDriver().findElement(By.xpath("(//div[@class='user-pan-right'])["+(a+1)+"]")).getText().split(":");
		dependPanNo=dependantPanNo[1].trim();
		
		nextsizeScheme=(getDriver().findElements(By.xpath("/html/body/div[2]/div[7]/div/div/div/div/div[1]/div/div["+((a+2)*3)+"]/div[2]/div/div[2]/div/div[2]/div/div[4]/div/div[1]/table/tbody/tr")).size())/2;
		String[]  nextdependantPanNo= getDriver().findElement(By.xpath("(//div[@class='user-pan-right'])["+(a+2)+"]")).getText().split(":");
		nextdependPanNo=nextdependantPanNo[1].trim();
			
			}
			catch(Exception e) {}
		}
		 //schemeNameSubHeaderCRM =getDriver().findElement(By.xpath("(//td[@style='padding:0'])["+schemeNum+"]//td")).getText();
		schemeNameSubHeaderCRM =getDriver().findElement(By.xpath("/html/body/div[2]/div[7]/div/div/div/div/div[1]/div/div["+(3*a)+"]/div[2]/div/div[2]/div/div[2]/div/div[4]/div/div[1]/table/tbody/tr["+(schemeNum+schemeNum-1)+"]/td[1]/table/tbody/tr/td")).getText();
		System.out.println(schemeNameSubHeaderCRM);
		Thread.sleep(2000);
		String schemeNoCRMElement = getDriver().findElement(By.xpath("/html/body/div[2]/div[7]/div/div/div/div/div[1]/div/div["+(3*a)+"]/div[2]/div/div[2]/div/div[2]/div/div[4]/div/div[1]/table/tbody/tr["+(schemeNum+(schemeNum-1))+"]")).getAttribute("id");
		System.out.println(schemeNoCRMElement);
		String[] schemeNoCRMElementArray = schemeNoCRMElement.split("_");
		String schemeNOCRMComplete = schemeNoCRMElementArray[1];
		String schemeNoCRM=schemeNOCRMComplete.substring(0,7);
		//schemeNameSubHeaderCRM =getDriver().findElement(By.xpath("(//td[@style='padding:0'])["+schemeNum+"]//td")).getText();
		schemeNameSubHeaderCRM =getDriver().findElement(By.xpath("/html/body/div[2]/div[7]/div/div/div/div/div[1]/div/div["+(3*a)+"]/div[2]/div/div[2]/div/div[2]/div/div[4]/div/div[1]/table/tbody/tr["+(schemeNum+schemeNum-1)+"]/td[1]/table/tbody/tr/td")).getText();
	    Thread.sleep(3000);
		String[] schemeNameCRMArray =schemeNameSubHeaderCRM.split(":");
	  String  folioNumCRM=schemeNameCRMArray[1].trim();
//		String unitsSubHeaderCRM=getDriver().findElement(By.xpath("(//td[@style='padding:0'])["+schemeNum+"]/following::td[3]")).getText().replaceAll(",", "");
//		String investSubHeaderCRM=getDriver().findElement(By.xpath("(//td[@style='padding:0'])["+schemeNum+"]/following::td[4]")).getText().replaceAll("[₹ ,]", "");
//		String currentValueSubHeaderCRM=getDriver().findElement(By.xpath("(//td[@style='padding:0'])["+schemeNum+"]/following::td[6]")).getText().replaceAll("[₹ ,]", "");
//		String cAGRSubHeaderCRM=getDriver().findElement(By.xpath("(//td[@style='padding:0'])["+schemeNum+"]/following::td[8]")).getText().replaceAll("[%]", "");
		
	  String unitsSubHeaderCRM=getDriver().findElement(By.xpath("/html/body/div[2]/div[7]/div/div/div/div/div[1]/div/div["+(3*a)+"]/div[2]/div/div[2]/div/div[2]/div/div[4]/div/div[1]/table/tbody/tr["+(schemeNum+(schemeNum-1))+"]/td[4]")).getText().replaceAll(",", "");
		String investSubHeaderCRM=getDriver().findElement(By.xpath("/html/body/div[2]/div[7]/div/div/div/div/div[1]/div/div["+(3*a)+"]/div[2]/div/div[2]/div/div[2]/div/div[4]/div/div[1]/table/tbody/tr["+(schemeNum+(schemeNum-1))+"]/td[5]")).getText().replaceAll("[₹ ,]", "");
		String currentValueSubHeaderCRM=getDriver().findElement(By.xpath("/html/body/div[2]/div[7]/div/div/div/div/div[1]/div/div["+(3*a)+"]/div[2]/div/div[2]/div/div[2]/div/div[4]/div/div[1]/table/tbody/tr["+(schemeNum+(schemeNum-1))+"]/td[7]")).getText().replaceAll("[₹ ,]", "");
		String cAGRSubHeaderCRM=getDriver().findElement(By.xpath("/html/body/div[2]/div[7]/div/div/div/div/div[1]/div/div["+(3*a)+"]/div[2]/div/div[2]/div/div[2]/div/div[4]/div/div[1]/table/tbody/tr["+(schemeNum+(schemeNum-1))+"]/td[9]")).getText().replaceAll("[%]", "");
		
		getDriver().get("https://www.financialhospital.in/adminpanel/Index.php");
	//	Thread.sleep(5000);
		getDriver().findElement(By
				.xpath("/html[1]/body[1]/div[2]/div[3]/div[1]/div[2]/div[2]/form[1]/div[1]/div[2]/h1[1]/input[1]"))
				.click();
	//	Thread.sleep(7000);
		ArrayList<String> windowHandles = new ArrayList<String>(getDriver().getWindowHandles());
		getDriver().switchTo().window(windowHandles.get(1));

		//Thread.sleep(5000);

		getDriver().findElement(By.xpath("//div/a[contains(text(),'Reports')]")).click();
		js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
		Select viewBy = new Select(getDriver().findElement(By.id("view")));
		viewBy.selectByVisibleText("Clients");
		if(a>=2) {
			getDriver().findElement(By.id("srch")).sendKeys(dependPanNo);
		}
		else {
		getDriver().findElement(By.id("srch")).sendKeys(reader.getCellData("Sheet1", "PAN", rowNumber));}
		//Thread.sleep(3000);
		getDriver().findElement(By.xpath("//form[@id='select_Client']")).click();
		getDriver().findElement(By.xpath("/html[1]/body[1]/div[5]/ul[1]/li[1]")).click();
		getDriver().findElement(By.xpath("/html[1]/body[1]/div[2]/div[3]/div[3]/dl[1]/dd[1]/form[1]/center[1]/table[1]/tbody[1]/tr[12]/td[1]/div[1]/input[1]")).click();
		ArrayList<String> windowHandles1 = new ArrayList<String>(getDriver().getWindowHandles());
		getDriver().switchTo().window(windowHandles1.get(2));
	//	Thread.sleep(3000);
		getDriver().findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[2]/table[2]/tbody[1]/tr[2]/td[1]/div[1]/div[1]")).click();
		js.executeScript("window.scrollBy(0,200)");
	  //  String unitsSubHeaderEwealth;
		//String investSubHeaderEwealth;
		//String currentValueSubHeaderEwealth;
		//String cAGRSubHeaderEwealth;
		int schemeSizeEwealth=getDriver().findElements(By.xpath("//tr[@class='graw-bg']")).size();
		for(int y=1; y<=schemeSizeEwealth;y++) {
		String schemeNameSubHeaderEwealth=getDriver().findElement(By.xpath("((//tr[@class='graw-bg'])["+y+"]/td)[1]")).getText();
		System.out.println(schemeNameSubHeaderEwealth);
		/*while(!(schemeNameSubHeaderEwealth==null)) {
			schemeNameSubHeaderEwealth =getDriver().findElement(By.xpath("((//tr[@class='graw-bg'])["+y+"]/td)[1]")).getText();
			schemeNameSubHeaderEwealth =getDriver().findElement(By.xpath("((//tr[@class='graw-bg'])["+y+"]/td)[1]")).getText();
			break;
		}*/
		Thread.sleep(3000);
		String schemeNoEwealthElement = getDriver().findElement(By.xpath("/html/body/div/div/div[2]/div[4]/section/div/div/div[1]/div/div/div/table/tbody/tr["+(y+(y-1))+"]")).getAttribute("id");
		System.out.println(schemeNoEwealthElement);
		String[] schemeNoEwealthElementArray = schemeNoEwealthElement.split("_");
		String schemeNoEwealth = schemeNoEwealthElementArray[2];
		//String schemeNoEwealth=schemeNOCRMComplete.substring(0,7);
		
		schemeNameSubHeaderEwealth =getDriver().findElement(By.xpath("((//tr[@class='graw-bg'])["+y+"]/td)[1]")).getText();
		String[] schemeNameArray=schemeNameSubHeaderEwealth.split(":");
	String folioNumEwealth01 =schemeNameArray[1].trim();
	String folioNumEwealth=folioNumEwealth01.split(" ")[0];
		
		if(schemeNoCRM.contains(schemeNoEwealth)) {
			 unitsSubHeaderEwealth=getDriver().findElement(By.xpath("((//tr[@class='graw-bg'])["+y+"]/td)[5]")).getText();
			 investSubHeaderEwealth=getDriver().findElement(By.xpath("((//tr[@class='graw-bg'])["+y+"]/td)[4]")).getText().replaceAll("[₹ ,]", "");
			 currentValueSubHeaderEwealth=getDriver().findElement(By.xpath("((//tr[@class='graw-bg'])["+y+"]/td)[9]")).getText().replaceAll("[₹ ,]", "");
			 cAGRSubHeaderEwealth=getDriver().findElement(By.xpath("((//tr[@class='graw-bg'])["+y+"]/td)[13]")).getText().replaceAll("%", "");
	      break;
		}}
		writer.setCellData("Sheet-1", "MFSubHeaderSchemeName", crmMFincrement01, schemeNameSubHeaderCRM);		
			writer.setCellData("Sheet-1", "MFInvestedSubHeaderValueCRM", crmMFincrement01, investSubHeaderCRM);
			writer.setCellData("Sheet-1", "MFCurrentSubHeaderValueCRM", crmMFincrement01, currentValueSubHeaderCRM);
			writer.setCellData("Sheet-1", "MFCAGRSubHeadeCRM", crmMFincrement01, cAGRSubHeaderCRM);
			writer.setCellData("Sheet-1", "MFUnitsSubHeadeCRM", crmMFincrement01, unitsSubHeaderCRM);
			writer.setCellData("Sheet-1", "MFInvestedSubHeaderValueEwealth", crmMFincrement01, investSubHeaderEwealth);
			writer.setCellData("Sheet-1", "MFCurrentSubHeaderValueEwealth", crmMFincrement01, currentValueSubHeaderEwealth);
			writer.setCellData("Sheet-1", "MFCAGRSubHeadeEwealth", crmMFincrement01, cAGRSubHeaderEwealth);
			writer.setCellData("Sheet-1", "MFUnitsSubHeadeEwealth", crmMFincrement01, unitsSubHeaderEwealth);
			
			double mfInvestValCRM=Double.parseDouble(investSubHeaderCRM);
			double mfCurrentValCRM =Double.parseDouble(currentValueSubHeaderCRM);
			double mfCAGRCRM =Double.parseDouble(cAGRSubHeaderCRM);
			double mfUnitsCRM =Double.parseDouble(unitsSubHeaderCRM);
			double investEwealth=Double.parseDouble(investSubHeaderEwealth);
			double currentEwealth=Double.parseDouble(currentValueSubHeaderEwealth);
			double mfCAGREwealth=Double.parseDouble(cAGRSubHeaderEwealth);
			double mfUnitsEwealth=Double.parseDouble(unitsSubHeaderEwealth);
			diffSubMFInvest =Double.toString(mfInvestValCRM-investEwealth);
			diffSubCurrent=Double.toString(mfCurrentValCRM-currentEwealth);
			diffSubCAGR= Double.toString(mfCAGRCRM-mfCAGREwealth);
			diffSubUnits= Double.toString(mfUnitsCRM-mfUnitsEwealth);
			writer.setCellData("Sheet-1", "MFInvestedSubHeaderDifference", crmMFincrement01, diffSubMFInvest);
			writer.setCellData("Sheet-1", "MFCurrentSubHeaderDifference", crmMFincrement01, diffSubCurrent);
			writer.setCellData("Sheet-1", "MFCAGRSubHeaderDifference", crmMFincrement01, diffSubCAGR);
			writer.setCellData("Sheet-1", "MFUnitsSubHeaderDifference", crmMFincrement01, diffSubUnits);
			getDriver().close();
			getDriver().switchTo().window(windowHandles1.get(1));
			getDriver().close();
			getDriver().switchTo().window(windowHandles1.get(0));
	
	}
	
	public static boolean isPresentAndDisplayed(final WebElement element) {
		  try {
		    return element.isDisplayed();
		  } catch (NoSuchElementException e) {
		    return false;
		  }
		}
	public Set<String> duplicatevalue(List<String> names){
		Set<String> store = new HashSet<>(); 
		for (String name : names) { 
			if (store.add(name) == false) { 
				System.out.println("found a duplicate element in array : " + name); } }

		return store;
		
	}
	public boolean isDuplicate(List<String> names,String otherFolio) {
		Set<String> foliono = duplicatevalue(names);
		//int duplicatefolioNo= foliono.size();
		for(Iterator<String> it = foliono.iterator();it.hasNext();) {
			String abc = it.next();
			if(abc.equals(otherFolio))
				return true;
			
			
		}
		return false;
	}


}
