package com.qa.scripts;

import java.util.Base64;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class RegisterAutomate {
	static WebDriver driver01;
	static Practice p = new Practice();
	 static String userName = "random32";
	 static String mailID = userName+"@yopmail.com";
	static By loginButton = By.xpath("//a[@href='/login/']");
	static {
		WebDriverManager.chromedriver().setup();
		 driver01 = new ChromeDriver();
		 p.createYOPmail(mailID, driver01);
		driver01.get("http://minty.co.in/");
		driver01.manage().window().maximize();
		driver01.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	
	public static void main(String[] args) throws InterruptedException {
		
		
		driver01.findElement(By.xpath("//a[@href='/login/']")).click();
		driver01.findElement(By.xpath("//a[@href='/register/']")).click();
		driver01.findElement(By.id("firstname")).sendKeys(RandomStringUtils.randomAlphabetic(6));
		driver01.findElement(By.id("email")).sendKeys(mailID);
		driver01.findElement(By.id("mobile")).sendKeys("9"+RandomStringUtils.randomNumeric(9));
		driver01.findElement(By.id("password")).sendKeys("Abc1234@gmail");
		driver01.findElement(By.id("repassword")).sendKeys("Abc1234@gmail");
		String value1 = driver01.findElement(By.id("captcha_code")).getAttribute("value");
		Base64.Decoder decoder = Base64.getDecoder();
		String captchaTxt = new String(decoder.decode(value1));
		driver01.findElement(By.id("captcha")).sendKeys(captchaTxt);
		driver01.findElement(By.id("chkterms")).click();
		driver01.findElement(By.id("reg")).click();
		Thread.sleep(5000);
		driver01.findElement(By.id("otp_code")).sendKeys(p.readOTPFromYopMail(mailID, driver01));
		driver01.findElement(By.xpath("//button[@value='Submit']")).click();
		Thread.sleep(9000);
		
		
	}
}
