package com.qa.base;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.DriverManager;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.WebDriverWait;
import io.github.bonigarcia.wdm.WebDriverManager;
import net.bytebuddy.agent.builder.AgentBuilder.DescriptionStrategy.SuperTypeLoading.Asynchronous;



public class TestBase {

	//public static ThreadLocal<ChromeDriver> driver = new ThreadLocal<>();
	public static ThreadLocal<WebDriver> driver = new ThreadLocal<WebDriver>();
	
	//public static WebDriver driver;
	public static Properties prop;
	public static WebDriverWait wait;

	public TestBase() {
		try {
			prop = new Properties();
			//FileInputStream ip = new FileInputStream("D:\\Vrushali\\Projects\\Portfolio\\Script\\src\\main\\java\\com\\qa\\config\\config.properties");
			FileInputStream ip = new FileInputStream("./src/main/java/com/qa/config/config.properties");
			prop.load(ip);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void initialization() {
		String browserName = prop.getProperty("browser");
		if (browserName.equals("chrome")) {
			//System.setProperty("webdriver.chrome.driver", "E:\\Sagar Nikam\\software\\chrome driver\\chromedriver.exe");
			Map<String, Object> prefs = new HashMap<String, Object>();
		      // browser setting to disable image
		      prefs.put("profile.managed_default_content_settings.notifications", 2);
		      //adding capabilities to browser
		      ChromeOptions op = new ChromeOptions();
		     // op.setExperimentalOption("prefs", prefs);
		      op.addArguments("headless");
		      DesiredCapabilities capabilities = new DesiredCapabilities();
		      capabilities.setCapability("headless",true);
			
			WebDriverManager.chromedriver().setup();
			//driver = new ChromeDriver(op);
			driver.set(new ChromeDriver());
		} else if (browserName.equals("firefox")) {
			System.setProperty("webdriver.gecko.driver", "D:\\Vrushali\\Drivers\\Firefox\\geckodriver-v0.26.0-win64\\geckodriver.exe");
			//driver = new FirefoxDriver();
			//driver.set(new FirefoxDriver());
		}

		getDriver().manage().window().maximize();
		getDriver().manage().deleteAllCookies();
		//driver.manage().timeouts().pageLoadTimeout(120, TimeUnit.SECONDS);
		getDriver().manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		getDriver().get(prop.getProperty("url"));
		//wait = new WebDriverWait(driver,30);
		
	}

	public  static synchronized WebDriver getDriver() {
		
		return driver.get();
	}
	public static void captureScreenshot(String methodName, WebDriver driver) {
		File source = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		try {
			String date = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
			FileUtils.copyFile(source, new File("D:\\Vrushali\\Projects\\Portfolio\\Script\\Screenshots" + methodName +" "+ date + ".png"));
			System.out.println("Screenshot Taken");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
