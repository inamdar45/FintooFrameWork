package com.qa.scripts;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.qa.base.TestBase;
import com.qa.util.Xls_Reader;

public class EWealth extends TestBase{
	Xls_Reader reader = new Xls_Reader("D:\\Vrushali\\Projects\\Portfolio\\Script\\src\\main\\java\\com\\qa\\testdata\\WBR.xlsx");
	public WebDriver driver;
	public EWealth() {
		PageFactory.initElements(driver, this);
	}
	
	
	
}
