package com.qa.scripts;

import com.qa.util.Xls_Reader;

import io.jsonwebtoken.io.IOException;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.qa.base.TestBase;

public class CRM01 extends TestBase {

	JavascriptExecutor js = (JavascriptExecutor) getDriver();
	//Xls_Reader reader = new Xls_Reader("E:\\Sagar Nikam\\AUM\\sample\\AUM_ByFundHouse.xlsx");
	Xls_Reader reader = new Xls_Reader("./src/main/java/com/qa/testdata/WBR.xlsx");
	String username = prop.getProperty("username");
	String password = prop.getProperty("password");
	
	static int k;
	static int i;
	static int j;
	static int l=2;
    static int temp;
    static int m;
    static int n;
    static int rowNum;
   static ArrayList<String> windowHandles1;

	static String AMCName_aum;
	static String Investment_aum;
	static String DivPaid_aum;
	static String DivReinv_aum;
	static String AUM_aum;
	static String AbsReturn_aum;
	static String AMCWeightage_aum;
	static String Equity_aum;
	static String Debt_aum;
	static String Hybrid_aum;
	static String SolOriented_aum;
	static String Others_aum;
	
	//String AMCName_ewealth;
	static String Investment_ewealth;
	static String DivPaid_ewealth;
	static String DivReinv_ewealth;
	static String AUM_ewealth;
	static String AbsReturn_ewealth;
	static String AMCWeightage_ewealth;
	static String Equity_ewealth;
	static String Debt_ewealth;
	static String Hybrid_ewealth;
	static String SolOriented_ewealth;
	static String Others_ewealth;


	public CRM01() {
		PageFactory.initElements(getDriver(), this);
		
	}

	public void getData() throws InterruptedException, java.io.IOException {
		getDriver().findElement(By.xpath("//input[@name='EmailID']")).sendKeys(username);
		getDriver().findElement(By.xpath("//input[@name='Password']")).sendKeys(password);
		getDriver().findElement(By.xpath("//button[@name='loginbtn']")).click();
		Thread.sleep(8000);
		
			
			
			

		Workbook wb = new XSSFWorkbook();
		FileOutputStream fileout = new FileOutputStream("E:\\Asif\\AUMREPORT32.xlsx");
		wb.write(fileout);
		fileout.close();
		Xls_Reader writer = new Xls_Reader("E:\\Asif\\AUMREPORT32.xlsx");
		writer.addSheet("Sheet-1");
		//writer.addColumn("Sheet-1", "Sr. No.");
		writer.addColumn("Sheet-1", "AMC Name aum");
		writer.addColumn("Sheet-1", "Investment aum");
		writer.addColumn("Sheet-1", "Div.Paid aum");
		writer.addColumn("Sheet-1", "Div.Reinv aum");
		writer.addColumn("Sheet-1", "AUM aum");
		writer.addColumn("Sheet-1", "Abs.Return aum");
		writer.addColumn("Sheet-1", "AMC Weightage aum");
		writer.addColumn("Sheet-1", "Equity aum");
		writer.addColumn("Sheet-1", "Debt aum");
		writer.addColumn("Sheet-1", "Hybrid aum");
		writer.addColumn("Sheet-1", "Sol Oriented aum");
		writer.addColumn("Sheet-1", "Others aum");
		
		//writer.addColumn("Sheet-1", "AMC Name ewealth");
		writer.addColumn("Sheet-1", "Investment ewealth");
		writer.addColumn("Sheet-1", "Div.Paid ewealth");
		writer.addColumn("Sheet-1", "Div.Reinv ewealth");
		writer.addColumn("Sheet-1", "AUM ewealth");
		writer.addColumn("Sheet-1", "Abs.Return ewealth");
		writer.addColumn("Sheet-1", "AMC Weightage ewealth");
		writer.addColumn("Sheet-1", "Equity ewealth");
		writer.addColumn("Sheet-1", "Debt ewealth");
		writer.addColumn("Sheet-1", "Hybrid ewealth");
		writer.addColumn("Sheet-1", "Sol Oriented ewealth");
		writer.addColumn("Sheet-1", "Others ewealth");
		

				
			for(i=1;i<=25;i++) {
				int rowCount = reader.getRowCount("Sheet1");
		    for (rowNum = 2; rowNum <= rowCount; rowNum++) {
					System.out.println(reader.getCellData("Sheet1", "AMCName", rowNum));
			getDriver().get("https://www.financialhospital.in/adminpanel/transaction/aum-report-fund.php");
			Thread.sleep(6000);
			getDriver().findElement(By.id("aum-report-table_filter")).click();
			Thread.sleep(5000);
			getDriver().findElement(By.xpath("//label[text()='Search:']"))
					.sendKeys(reader.getCellData("Sheet1", "AMCName", rowNum));
			
			Thread.sleep(5000);
			
			
								//AUM Report
							
							writer.setCellData("Sheet-1", "AMCName", rowNum, reader.getCellData("Sheet1", "AMCName", rowNum));
							AMCName_aum = getDriver().findElement(By.xpath("/html[1]/body[1]/div[1]/div[7]/div[1]/div[1]/div[2]/form[1]/div[1]/table[1]/thead[1]/tr[1]/th[2]")).getText();
							Investment_aum = getDriver().findElement(By.xpath("/html[1]/body[1]/div[1]/div[7]/div[1]/div[1]/div[2]/form[1]/div[1]/table[1]/thead[1]/tr[1]/th[3]")).getText();
							DivPaid_aum = getDriver().findElement(By.xpath("/html[1]/body[1]/div[1]/div[7]/div[1]/div[1]/div[2]/form[1]/div[1]/table[1]/thead[1]/tr[1]/th[4]")).getText();
							DivReinv_aum = getDriver().findElement(By.xpath("/html[1]/body[1]/div[1]/div[7]/div[1]/div[1]/div[2]/form[1]/div[1]/table[1]/thead[1]/tr[1]/th[5]")).getText();
							AUM_aum = getDriver().findElement(By.xpath("/html[1]/body[1]/div[1]/div[7]/div[1]/div[1]/div[2]/form[1]/div[1]/table[1]/thead[1]/tr[1]/th[6]")).getText();
							AbsReturn_aum = getDriver().findElement(By.xpath("/html[1]/body[1]/div[1]/div[7]/div[1]/div[1]/div[2]/form[1]/div[1]/table[1]/thead[1]/tr[1]/th[7]")).getText();
							AMCWeightage_aum = getDriver().findElement(By.xpath("/html[1]/body[1]/div[1]/div[7]/div[1]/div[1]/div[2]/form[1]/div[1]/table[1]/thead[1]/tr[1]/th[8]")).getText();
							Equity_aum = getDriver().findElement(By.xpath("/html[1]/body[1]/div[1]/div[7]/div[1]/div[1]/div[2]/form[1]/div[1]/table[1]/thead[1]/tr[1]/th[9]")).getText();
							Debt_aum = getDriver().findElement(By.xpath("/html[1]/body[1]/div[1]/div[7]/div[1]/div[1]/div[2]/form[1]/div[1]/table[1]/thead[1]/tr[1]/th[10]")).getText();
							Hybrid_aum = getDriver().findElement(By.xpath("/html[1]/body[1]/div[1]/div[7]/div[1]/div[1]/div[2]/form[1]/div[1]/table[1]/thead[1]/tr[1]/th[11]")).getText();
							SolOriented_aum = getDriver().findElement(By.xpath("/html[1]/body[1]/div[1]/div[7]/div[1]/div[1]/div[2]/form[1]/div[1]/table[1]/thead[1]/tr[1]/th[12]")).getText();
							Others_aum = getDriver().findElement(By.xpath("/html[1]/body[1]/div[1]/div[7]/div[1]/div[1]/div[2]/form[1]/div[1]/table[1]/thead[1]/tr[1]/th[13]")).getText();
							  
							Thread.sleep(5000);
							writer.setCellData("Sheet-1", "AMC Name aum", rowNum,
							getDriver().findElement(By.xpath("/html[1]/body[1]/div[1]/div[7]/div[1]/div[1]/div[2]/form[1]/div[1]/table[1]/tbody[1]/tr[1]/td[2]/a[1]")).getText());
							writer.setCellData("Sheet-1", "Investment aum", rowNum,
							getDriver().findElement(By.xpath("/html[1]/body[1]/div[1]/div[7]/div[1]/div[1]/div[2]/form[1]/div[2]/table[1]/tbody[1]/tr[1]/td[3]")).getText());
							writer.setCellData("Sheet-1", "Div.Paid aum", rowNum,
							getDriver().findElement(By.xpath("/html[1]/body[1]/div[1]/div[7]/div[1]/div[1]/div[2]/form[1]/div[2]/table[1]/tbody[1]/tr[1]/td[4]")).getText());
							writer.setCellData("Sheet-1", "Div.Reinv aum", rowNum,
							getDriver().findElement(By.xpath("/html[1]/body[1]/div[1]/div[7]/div[1]/div[1]/div[2]/form[1]/div[2]/table[1]/tbody[1]/tr[1]/td[5]")).getText());
							writer.setCellData("Sheet-1", "AUM aum", rowNum,
						    getDriver().findElement(By.xpath("/html[1]/body[1]/div[1]/div[7]/div[1]/div[1]/div[2]/form[1]/div[2]/table[1]/tbody[1]/tr[1]/td[6]")).getText());
							writer.setCellData("Sheet-1", "Abs.Return aum", rowNum,
						    getDriver().findElement(By.xpath("/html[1]/body[1]/div[1]/div[7]/div[1]/div[1]/div[2]/form[1]/div[1]/table[1]/tbody[1]/tr[1]/td[7]")).getText());
							writer.setCellData("Sheet-1", "AMC Weightage aum", rowNum,
							getDriver().findElement(By.xpath("/html[1]/body[1]/div[1]/div[7]/div[1]/div[1]/div[2]/form[1]/div[1]/table[1]/tbody[1]/tr[1]/td[8]")).getText());
							writer.setCellData("Sheet-1", "Equity aum", rowNum,
							getDriver().findElement(By.xpath("/html[1]/body[1]/div[1]/div[7]/div[1]/div[1]/div[2]/form[1]/div[1]/table[1]/tbody[1]/tr[1]/td[9]")).getText());
							writer.setCellData("Sheet-1", "Debt aum", rowNum,
							getDriver().findElement(By.xpath("/html[1]/body[1]/div[1]/div[7]/div[1]/div[1]/div[2]/form[1]/div[1]/table[1]/tbody[1]/tr[1]/td[10]")).getText());
							writer.setCellData("Sheet-1", "Hybrid aum", rowNum,
						    getDriver().findElement(By.xpath("/html[1]/body[1]/div[1]/div[7]/div[1]/div[1]/div[2]/form[1]/div[1]/table[1]/tbody[1]/tr[1]/td[11]")).getText());
							writer.setCellData("Sheet-1", "Sol Oriented aum", rowNum,
							getDriver().findElement(By.xpath("/html[1]/body[1]/div[1]/div[7]/div[1]/div[1]/div[2]/form[1]/div[1]/table[1]/tbody[1]/tr[1]/td[12]")).getText());
							writer.setCellData("Sheet-1", "Others aum", rowNum,
							getDriver().findElement(By.xpath("/html[1]/body[1]/div[1]/div[7]/div[1]/div[1]/div[2]/form[1]/div[1]/table[1]/tbody[1]/tr[1]/td[13]")).getText());
						
						
			          // eWealth
					
			Thread.sleep(3000);
			getDriver().get("https://www.financialhospital.in/adminpanel/Index.php");
			Thread.sleep(5000);
			getDriver().findElement(By
					.xpath("/html[1]/body[1]/div[2]/div[3]/div[1]/div[2]/div[2]/form[1]/div[1]/div[2]/h1[1]/input[1]"))
					.click();
			Thread.sleep(5000);
			ArrayList<String> windowHandles = new ArrayList<String>(getDriver().getWindowHandles());
			getDriver().switchTo().window(windowHandles.get(1));
			//getDriver().findElement(By.xpath("//tbody/tr[2]/td[2]/div[2]/div[1]/div[4]")).click();
			Thread.sleep(5000);
			
			
			
			getDriver().findElement(By.xpath("/html[1]/body[1]/div[9]/div[2]/div[2]/div[8]/a[1]")).click();
			Thread.sleep(2000);
			getDriver().findElement(By.xpath("/html[1]/body[1]/div[2]/div[4]/center[1]/table[2]/tbody[1]/tr[1]/td[2]/center[1]/a[1]")).click();
		    Thread.sleep(3000);
		    getDriver().findElement(By.xpath("/html[1]/body[1]/div[2]/div[3]/div[2]/div[1]/div[2]/h3[1]/a[1]")).click();
		    getDriver().findElement(By.xpath("/html[1]/body[1]/div[2]/div[3]/div[2]/form[1]/table[1]/tbody[1]/tr[3]/td[4]/input[1]")).click();
		    Thread.sleep(2000);
		    
				    
		    
				  windowHandles1 = new ArrayList<String>(getDriver().getWindowHandles());
				getDriver().switchTo().window(windowHandles1.get(2));
				
				Thread.sleep(3000);
									  if(i<=25) {
								
							                for(l=2;l<=13;l++) {
									  
								                        if(l==2) {
									 
									         writer.setCellData("Sheet-1", "Investment ewealth", rowNum,
											 getDriver().findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/table[2]/tbody[1]/tr["+i+"]/td["+ ++l +"]")).getText());
											 writer.setCellData("Sheet-1", "Div.Paid ewealth", rowNum,
											 getDriver().findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/table[2]/tbody[1]/tr["+i+"]/td["+ ++l +"]")).getText());
											 writer.setCellData("Sheet-1", "Div.Reinv ewealth", rowNum,
											 getDriver().findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/table[2]/tbody[1]/tr["+i+"]/td["+ ++l +"]")).getText());
													  
											 writer.setCellData("Sheet-1", "AUM ewealth", rowNum,
											 getDriver().findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/table[2]/tbody[1]/tr["+i+"]/td["+ ++l +"]")).getText());
											 writer.setCellData("Sheet-1", "Abs.Return ewealth", rowNum,
											 getDriver().findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/table[2]/tbody[1]/tr["+i+"]/td["+ ++l +"]")).getText());
											 writer.setCellData("Sheet-1", "AMC Weightage ewealth", rowNum,
											 getDriver().findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/table[2]/tbody[1]/tr["+i+"]/td["+ ++l +"]")).getText());
											 writer.setCellData("Sheet-1", "Equity ewealth", rowNum,
											 getDriver().findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/table[2]/tbody[1]/tr["+i+"]/td["+ ++l +"]")).getText());
											 writer.setCellData("Sheet-1", "Debt ewealth", rowNum,
											 getDriver().findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/table[2]/tbody[1]/tr["+i+"]/td["+ ++l +"]")).getText());
											 writer.setCellData("Sheet-1", "Hybrid ewealth", rowNum,
											 getDriver().findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/table[2]/tbody[1]/tr["+i+"]/td["+ ++l +"]")).getText());
											 writer.setCellData("Sheet-1", "Sol Oriented ewealth", rowNum,
											 getDriver().findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/table[2]/tbody[1]/tr["+i+"]/td["+ ++l +"]")).getText());
											 writer.setCellData("Sheet-1", "Others ewealth", rowNum,
											 getDriver().findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/table[2]/tbody[1]/tr["+i+"]/td["+ ++l +"]")).getText());
											 
											 ++i;
									 
								 }
								 
								 	 
								 
						  }
								
							  
						 
				 }
				
			    getDriver().close();
				getDriver().switchTo().window(windowHandles1.get(1));
				getDriver().close();
				getDriver().switchTo().window(windowHandles1.get(0));

			try {
				if (Investment_aum != null && Investment_ewealth != null) {
					if (!(Investment_aum.equals(Investment_ewealth))) {
						writer.setCellData("Sheet-1", "Investment aum", rowNum, Investment_aum);
						writer.setCellData("Sheet-1", "Investment eWealth", rowNum, Investment_ewealth);
					}
					if (!(DivPaid_aum.equals(DivPaid_ewealth))) {
						writer.setCellData("Sheet-1", "Div.Paid aum", rowNum, DivPaid_aum);
						writer.setCellData("Sheet-1", "Div.Paid eWealth", rowNum, DivPaid_ewealth);
					}
					if (!(DivReinv_aum.equals(DivReinv_ewealth))) {
						writer.setCellData("Sheet-1", "Div.Reinv aum", rowNum, DivReinv_aum);
						writer.setCellData("Sheet-1", "Div.Reinv eWealth", rowNum, DivReinv_ewealth);
					}
					if (!(AUM_aum.equals(AUM_ewealth))) {
						writer.setCellData("Sheet-1", "AUM aum", rowNum, AUM_aum);
						writer.setCellData("Sheet-1", "AUM eWealth", rowNum, AUM_ewealth);
					}
					if (!(AbsReturn_aum.equals(AbsReturn_ewealth))) {
						writer.setCellData("Sheet-1", "Abs.Return aum", rowNum, AbsReturn_aum);
						writer.setCellData("Sheet-1", "Abs.Return eWealth", rowNum, AbsReturn_ewealth);
					}
					if (!(AMCWeightage_aum.equals(AMCWeightage_ewealth))) {
						writer.setCellData("Sheet-1", "AMC Weightage aum", rowNum, AMCWeightage_aum);
						writer.setCellData("Sheet-1", "AMC Weightage eWealth", rowNum, AMCWeightage_ewealth);
					}
					if (!(Equity_aum.equals(Equity_ewealth))) {
						writer.setCellData("Sheet-1", "Equity aum", rowNum, Equity_aum);
						writer.setCellData("Sheet-1", "Equity eWealth", rowNum, Equity_ewealth);
					}
					if (!(Debt_aum.equals(Debt_ewealth))) {
						writer.setCellData("Sheet-1", "Debt aum", rowNum, Debt_aum);
						writer.setCellData("Sheet-1", "Debt eWealth", rowNum, Debt_ewealth);
					}
					if (!(Hybrid_aum.equals(Hybrid_ewealth))) {
						writer.setCellData("Sheet-1", "Hybrid aum", rowNum, Hybrid_aum);
						writer.setCellData("Sheet-1", "Hybrid eWealth", rowNum, Hybrid_ewealth);
					}
					if (!(SolOriented_aum.equals(SolOriented_ewealth))) {
						writer.setCellData("Sheet-1", "Sol Oriented aum", rowNum, SolOriented_aum);
						writer.setCellData("Sheet-1", "Sol Oriented eWealth", rowNum, SolOriented_ewealth);
					}
					if (!(Others_aum.equals(Others_ewealth))) {
						writer.setCellData("Sheet-1", "Div.Reinv aum", rowNum, Others_aum);
						writer.setCellData("Sheet-1", "Div.Reinv eWealth", rowNum, Others_ewealth);
					}
				
					
	                AMCName_aum="";
	                Investment_aum="";
	                DivPaid_aum="";
	                DivReinv_aum="";
	                AUM_aum="";
	                AbsReturn_aum="";
	                AMCWeightage_aum="";
	                Equity_aum="";
	                Debt_aum="";
	                Hybrid_aum="";
	                SolOriented_aum="";
	                Others_aum="";
		                 
	                 Investment_ewealth="";
	                 DivPaid_ewealth="";
	                 DivReinv_ewealth="";
	                 AUM_ewealth="";
	                 AbsReturn_ewealth="";
	                 AMCWeightage_ewealth="";
	                 Equity_ewealth="";
	                 Debt_ewealth="";
	                 Hybrid_ewealth="";
	                 SolOriented_ewealth="";
	                 Others_ewealth="";

					   

				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		
		}	
		++i;
			 
				}
			
		
				
				
			
			
		  
		  

	  
			// continue;
			

		}

	}

	
