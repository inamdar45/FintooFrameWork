package com.qa.runScript;

import java.io.IOException;
import java.time.Duration;

import org.joda.time.Instant;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.scripts.CRM;
import com.qa.scripts.CRM01;
import com.qa.scripts.CRMA;
import com.qa.scripts.CRMB;
import com.qa.scripts.PanWithPortfolio;

public class RunScript extends TestBase{
	
	CRM crm;
	CRMA crmA;
	CRMB crmB;
	long start,stop;
	PanWithPortfolio PP;
	
	public RunScript() {
		super();
	}
	
	
	@BeforeMethod
	public void setup() {
		 start=System.currentTimeMillis();
		super.initialization();
	}
	
	//@Test
	public void runScriptTest() throws InterruptedException, IOException {
	//	crm = new CRM();
	//	crm.getData("./src/main/java/com/qa/testdata/WBR1.xlsx","D:\\Portfolios170.xlsx");
		PP= new PanWithPortfolio();
		PP.panWithPortfolio();
	}
	
	@Test
	public void runScriptTest01() throws InterruptedException, IOException {
		//Thread.sleep(8000);
		crm = new CRM();
		crm.getData("./src/main/java/com/qa/testdata/WBR3.xlsx","D:\\Portfolios170.xlsx");
	}
	
	//@Test3
	public void runScriptTest02() throws InterruptedException, IOException {
		//Thread.sleep(18000);
		crm = new CRM();
		crm.getData("./src/main/java/com/qa/testdata/WBR3.xlsx","D:\\Portfolios172.xlsx");
	}
	
	//@Test
	public void runScriptTest03() throws InterruptedException, IOException {
		crm = new CRM();
		crm.getData("./src/main/java/com/qa/testdata/WBR4.xlsx","D:\\Portfolios173.xlsx");
	}
	
//	@Test
	public void runScriptTest04() throws InterruptedException, IOException {
		crm = new CRM();
		crm.getData("./src/main/java/com/qa/testdata/WBR5.xlsx","D:\\Portfolios174.xlsx");
	}
	
	@AfterMethod
	public void tearDown() {
		 stop=System.currentTimeMillis();
		System.out.println(stop-start);
		//TestBase.driver.quit();
	}
		

}
