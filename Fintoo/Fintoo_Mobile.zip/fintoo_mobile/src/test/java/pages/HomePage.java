package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class HomePage {
	public AndroidDriver<MobileElement> androiddriver;
	
	public By letsStartLabel = By.id("com.financialhospital.admin.finh:id/sliding_banner_image");
	public By calculatorButton = By.xpath("//android.widget.TextView[@text='CALCULATOR']");
    public By termPlanCalButton = By.xpath("//android.widget.TextView[@text='TERM PLAN CALCULATOR']");
    public By sipCalButton = By.xpath("//android.widget.TextView[@text='SIP CALCULATOR']");
    //Locators for term plan calculators.
    public By lifeValCalBtn= By.xpath("//android.widget.TextView[@text='Life Value Calculator']");
    public By monthlyExpField = By.id("com.financialhospital.admin.finh:id/goalval");
    public By reqMoneyForYearsTxt  = By.id("com.financialhospital.admin.finh:id/yearsval");
    public By takenLifeCoverTxt = By .id("com.financialhospital.admin.finh:id/rorval");
    public By pendingDebtTxt = By.id("com.financialhospital.admin.finh:id/debt_edit_text");
    public By addAssumpBtn = By.id("com.financialhospital.admin.finh:id/view_more");
    public By calculateBtn= By.id("com.financialhospital.admin.finh:id/calculate");
    public By rorEditTxt = By.id("com.financialhospital.admin.finh:id/ror_edit_text");
    public By inflationRateTxt = By.id("com.financialhospital.admin.finh:id/inflation_edit_text");
    public By netLifeCoverVal = By.xpath("//android.widget.TextView[@text='Net Life cover needed']/preceding::android.widget.TextView[1]");
    
    //Locators for Premium Calculator
    public By premiumCalBtn= By.xpath("//android.widget.TextView[@text='Premium calculator']");
	
    
    public HomePage(AndroidDriver<MobileElement> androiddriver) {
			this.androiddriver = androiddriver;
			PageFactory.initElements(androiddriver, this);

		}
	  
	  public boolean genericClick(AndroidDriver<MobileElement> androiddriver, By elementToBeClicked)
		{

		    try{

		    	androiddriver.findElement(elementToBeClicked).click();

		     return true;
		}
		catch(Exception e){

		     return false;
		}

		}
	  
	  public boolean genericSendKeys(AndroidDriver<MobileElement> androiddriver, By elementToBeClicked,String text)
		{

		    try{
		    	//androiddriver.findElement(elementToBeClicked).clear();
		    	androiddriver.findElement(elementToBeClicked).click();
		    	androiddriver.findElement(elementToBeClicked).sendKeys(text);

		     return true;
		}
		catch(Exception e){

		     return false;
		}

		}

	
}
