package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class PlanPage {
	public AndroidDriver<MobileElement> androiddriver;
	public By financialPlanAddBtn = By.xpath("//android.widget.TextView[@text='Add +']");
	public By viewCartSummBtn = By.id("com.financialhospital.admin.finh:id/btnViewCartSummary");
	public By applyOfferBtn = By.id("com.financialhospital.admin.finh:id/btnApply");
	public By fintoo100ApplyBtn = By.id("com.financialhospital.admin.finh:id/btnApply");
	public By startPlanningBtn = By.id("com.financialhospital.admin.finh:id/btnSubmit");
	// profile fill in details locators
	public By firstNameField = By.id("com.financialhospital.admin.finh:id/etFirstName");
	public By lastNameField = By.id("com.financialhospital.admin.finh:id/etLastName");
	public By emailField = By.id("com.financialhospital.admin.finh:id/etEmail");
	public By mobileField = By.id("com.financialhospital.admin.finh:id/etMobile");
	public By panField = By.id("com.financialhospital.admin.finh:id/etPan");
	public By pincodeField = By.id("com.financialhospital.admin.finh:id/etPincode");
	public By profileSubmitBtn = By.id("com.financialhospital.admin.finh:id/btnSaveProfile");
	public By continuePlanningBtn = By.id("com.financialhospital.admin.finh:id/btnContinuePlanning");
	//Locators for Income
	public By incomeLabel = By.xpath("//android.widget.TextView[@text='INCOME']");
	public By netIncomeValTxt = By.id("com.financialhospital.admin.finh:id/etNetIncomeValueInput");
	public By incomeFrom = By.id("com.financialhospital.admin.finh:id/etGoalForInput");
	public By fixVarToggBtn =By.id("com.financialhospital.admin.finh:id/swFixedVariable");
	public By oneRecurToggBtn = By.id("com.financialhospital.admin.finh:id/swEquity");
	public By incomeStartDateField = By.id("com.financialhospital.admin.finh:id/etIncomeStartDateInput");
	public By calenderYear = By.id("android:id/date_picker_header_year");
	public By calenderMonthDate = By.id("android:id/date_picker_header_date");
	public By monthYearNext = By.id("android:id/next");
	public By endDateAnnualIncomeField = By.id("com.financialhospital.admin.finh:id/etIncomeEndDateInput");
	public By calenderOkButton = By.id("android:id/button1");
	public By freqDropDown = By.id("com.financialhospital.admin.finh:id/etFrequencyInput");
	public By remarkField = By.id("com.financialhospital.admin.finh:id/etRemarksInput");
	public By saveBtn = By.id("com.financialhospital.admin.finh:id/btnSave");
	//Locators for expenses
	public By expenseLabel = By.xpath("//android.widget.TextView[@text='EXPENSES']");
	//Locators for Assets
	public By assetsLabel = By.xpath("//android.widget.TextView[@text='ASSETS']");
	//Locators for Liabilities
	public By liabilitiesLabel = By.xpath("//android.widget.TextView[@text='LIABILITIES']");
	//Locators for Goals
	public By goalLabel = By.xpath("//android.widget.TextView[@text='GOALS']");
	
	public PlanPage(AndroidDriver<MobileElement> androiddriver) {
		this.androiddriver = androiddriver;
		PageFactory.initElements(androiddriver, this);

	}
  
  public boolean genericClick(AndroidDriver<MobileElement> androiddriver, By elementToBeClicked)
	{

	    try{

	    	androiddriver.findElement(elementToBeClicked).click();

	     return true;
	}
	catch(Exception e){

	     return false;
	}

	}
  
  public boolean genericSendKeys(AndroidDriver<MobileElement> androiddriver, By elementToBeClicked,String text)
	{

	    try{
	    	//androiddriver.findElement(elementToBeClicked).clear();
	    	androiddriver.findElement(elementToBeClicked).click();
	    	androiddriver.findElement(elementToBeClicked).sendKeys(text);

	     return true;
	}
	catch(Exception e){

	     return false;
	}

	}


}
