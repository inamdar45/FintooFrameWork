package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class LoginPage {
  public AndroidDriver<MobileElement> androiddriver;
  public By loginButton = By.id("com.financialhospital.admin.finh:id/login_button");
  public By emailButton = By.id("com.financialhospital.admin.finh:id/register_button");
  public By msgTextBoxField = By.id("com.financialhospital.admin.finh:id/input_edit_text");
  public By sendArrowBtn = By.id("com.financialhospital.admin.finh:id/send_button");
  public By passwordBtn = By.id("com.financialhospital.admin.finh:id/register_button");
  public By passwordTxtField = By.id("com.financialhospital.admin.finh:id/password_edit_text");
  public By submitBtn = By.id("com.financialhospital.admin.finh:id/submit_password");
  
  public LoginPage(AndroidDriver<MobileElement> androiddriver) {
		this.androiddriver = androiddriver;
		PageFactory.initElements(androiddriver, this);

	}
  
  public boolean genericClick(AndroidDriver<MobileElement> androiddriver, By elementToBeClicked)
	{

	    try{

	    	androiddriver.findElement(elementToBeClicked).click();

	     return true;
	}
	catch(Exception e){

	     return false;
	}

	}
  
  public boolean genericSendKeys(AndroidDriver<MobileElement> androiddriver, By elementToBeClicked,String text)
	{

	    try{
	    	androiddriver.findElement(elementToBeClicked).clear();
	    	androiddriver.findElement(elementToBeClicked).sendKeys(text);

	     return true;
	}
	catch(Exception e){

	     return false;
	}

	}

	
}
