package testcases;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.ChartLocation;
import com.aventstack.extentreports.reporter.configuration.Theme;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;
import pages.LoginPage;
import utilities.ReadConfig;
import utilities.XLUtils;

public class BaseClass {
	
	public static ExtentHtmlReporter htmlReporter;
	public static ExtentReports extent;
	public static ExtentTest logger;
	ITestResult tr;
	public static ThreadLocal<ExtentTest> extentTest = new ThreadLocal<ExtentTest>();
	public static AndroidDriver<MobileElement> androiddriver;
	static ReadConfig readconfig = new ReadConfig();
	String timeDateVar,datetimeVar;
	String excelPath = readconfig.getExcelPath();
	
	@BeforeSuite
	public void beforeStart() {

		String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());// time stamp
		String repName = "Test-Report-" + timeStamp + ".html";

		htmlReporter = new ExtentHtmlReporter(System.getProperty("user.dir") + "/extent-report/" + repName);// specify
																											// location
																											// of the
																											// report
		htmlReporter.setAppendExisting(true);
		htmlReporter.loadXMLConfig(System.getProperty("user.dir") + "/extent-config.xml");

		extent = new ExtentReports();

		extent.attachReporter(htmlReporter);
		extent.setSystemInfo("Host name", "localhost");
		extent.setSystemInfo("Environemnt", "QA");
		extent.setSystemInfo("user", "Asif");

		htmlReporter.config().setDocumentTitle("Finance Test Project"); // Tile of report
		htmlReporter.config().setReportName("Functional Test Automation Report"); // name of the report
		htmlReporter.config().setTestViewChartLocation(ChartLocation.TOP); // location of the chart
		htmlReporter.config().setTheme(Theme.DARK);
		
	
	}
	@BeforeClass
	public void start() throws InterruptedException, IOException {
		
		String deviceName=XLUtils.getCellData(excelPath, "Capabilities", 1, 0);
		String platformName=XLUtils.getCellData(excelPath, "Capabilities", 1, 1);
		String platformVersion=XLUtils.getCellData(excelPath, "Capabilities", 1, 2);
		String appPath=XLUtils.getCellData(excelPath, "Capabilities", 1, 3);
		DesiredCapabilities dC= new DesiredCapabilities();
		//	dC.setCapability(MobileCapabilityType.AUTOMATION_NAME, "Appium");
			dC.setCapability(MobileCapabilityType.DEVICE_NAME,deviceName);
			dC.setCapability(MobileCapabilityType.PLATFORM_VERSION,platformVersion);
			dC.setCapability(MobileCapabilityType.PLATFORM_NAME,platformName);
		//	dC.setCapability("appPackage","com.financialhospital.admin.finh");
		//	dC.setCapability("appActivity","com.financialhospital.admin.finh.activity.dataGathering.income.IncomeFormsActivity");
		//	dC.setCapability("app","C:\\Users\\Hp\\Downloads\\5_6222216754911773558.apk");
			dC.setCapability("app",appPath);
			dC.setCapability("autoGrantPermissions",true);
			dC.setCapability("unicodeKeyboard",true);
			dC.setCapability("resetKeyboard",true);
			
			URL url = new URL("http://127.0.0.1:4723/wd/hub");
			 androiddriver = new AndroidDriver<MobileElement>(url,dC);
			Thread.sleep(5000);
		    androiddriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	
	/*public static void main(String[] args) throws MalformedURLException, InterruptedException {
		DesiredCapabilities dC= new DesiredCapabilities();
	//	dC.setCapability(MobileCapabilityType.AUTOMATION_NAME, "Appium");
		dC.setCapability(MobileCapabilityType.DEVICE_NAME, "RZ8N91CAVEH");
		dC.setCapability(MobileCapabilityType.PLATFORM_VERSION, "11.0");
		dC.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
	//	dC.setCapability("appPackage","com.financialhospital.admin.finh");
	//	dC.setCapability("appActivity","com.financialhospital.admin.finh.activity.dataGathering.income.IncomeFormsActivity");
		dC.setCapability("app","C:\\Users\\Hp\\Downloads\\5_6222216754911773558.apk");
		dC.setCapability("autoGrantPermissions",true);
		
		URL url = new URL("http://127.0.0.1:4723/wd/hub");
		AndroidDriver<WebElement> androiddriver = new AndroidDriver<WebElement>(url,dC);
		Thread.sleep(5000);
		LoginPage lp = new LoginPage(androiddriver);
		lp.genericClick(androiddriver, lp.loginButton);
		Thread.sleep(5000);
		
	//	WebElement allowButton = androiddriver.findElement(By.xpath("//android.widget.Button[@resource-id='com.android.packageinstaller:id/permission_allow_button'])"));
		//allowButton.click();
	}*/
	@AfterMethod
	public void tearDown(ITestResult result) {
		//driver.quit();
		// extent.flush();
		if (result.getStatus() == ITestResult.FAILURE) {

			htmlReporter.setAppendExisting(true);
			AndroidDriver<WebElement> androiddriver = null;
			extentTest.get().fail(result.getThrowable());
			Object testObject = result.getInstance();
			Class clazz = result.getTestClass().getRealClass();
			try {
				androiddriver = (AndroidDriver<WebElement>) clazz.getDeclaredField("androiddriver").get(testObject);
			} catch (Exception e) {
				// TODO Auto-generated catch block

			}
			try {
				captureScreen(result.getMethod().getMethodName());
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

			String screenshotPath = System.getProperty("user.dir") + "\\Screenshots\\"
					+ result.getMethod().getMethodName()+datetimeVar+ ".png";

			File f = new File(screenshotPath);

			if (f.exists()) {
				try {
					extentTest.get()
							.fail("Screenshot is below:" + extentTest.get().addScreenCaptureFromPath(screenshotPath));
				} catch (IOException e) {
					e.printStackTrace();
				}
			}

		}
		if (result.getStatus() == ITestResult.SUCCESS) {
			extentTest.get().log(Status.PASS,
					MarkupHelper.createLabel(result.getMethod().getMethodName(), ExtentColor.GREEN)); // send the passed
																										// information
			}
		if (result.getStatus() == ITestResult.SKIP) {
			extentTest.get().log(Status.SKIP, MarkupHelper.createLabel(result.getName(), ExtentColor.ORANGE));
		}

	}
	
	@AfterSuite
	public void down() {
		//driver.close();
		extent.flush();
	}
	
	public void captureScreen(String tname) throws IOException {
		 timeDateVar = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
		 datetimeVar=timeDateVar;
		TakesScreenshot ts = (TakesScreenshot) androiddriver;
		File source = ts.getScreenshotAs(OutputType.FILE);
		File target = new File(System.getProperty("user.dir") + "/Screenshots/" + tname + datetimeVar +".png");
		System.out.println(target.toString());
		FileUtils.copyFile(source, target);
		System.out.println("Screenshot taken");
	}

}
