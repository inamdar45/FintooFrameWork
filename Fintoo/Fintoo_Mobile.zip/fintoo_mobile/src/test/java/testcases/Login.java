package testcases;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.fail;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.touch.TouchActions;
import org.testng.Assert;
import org.testng.annotations.Test;

import pages.HomePage;
import pages.LoginPage;
import utilities.Functions;
import utilities.XLUtils;

public class Login extends BaseClass {

	LoginPage lp = new LoginPage(androiddriver);
	HomePage hp = new HomePage(androiddriver);
	Functions fun= new Functions(androiddriver);
	//String excelPath = readconfig.getExcelPath();
	@Test
	public void login() throws InterruptedException, IOException {
		logger = extent.createTest("Login And Start plan");
		extentTest.set(logger);
		
		String userName=XLUtils.getCellData(excelPath, "login_data", 1, 0);
		String password=XLUtils.getCellData(excelPath, "login_data", 1, 1);
		lp.genericClick(androiddriver, lp.loginButton);
		logger.pass("Clicked on Login Button");
		Thread.sleep(5000);
		lp.genericClick(androiddriver, lp.emailButton);
		logger.pass("Clicked on Email");
		lp.genericSendKeys(androiddriver, lp.msgTextBoxField, userName);
		logger.pass("UserName Entered is" +userName);
		lp.genericClick(androiddriver, lp.sendArrowBtn);
		logger.pass("Clicked on send arrow");
		lp.genericClick(androiddriver, lp.passwordBtn);
		logger.pass("Clicked on Password Button");
		//Assert.fail("failed");
		lp.genericSendKeys(androiddriver, lp.passwordTxtField, password);
		logger.pass("Password Entered is" + password); 
		lp.genericClick(androiddriver, lp.submitBtn);
		logger.pass("Clicked on Submit Button");
		Thread.sleep(5000);
	}
	//@Test(dependsOnMethods = "login")
	public void lifeValCal() throws IOException {
		String monthlyExp=XLUtils.getCellData(excelPath, "LifeValCalculator", 1, 0);
		String reqYears=XLUtils.getCellData(excelPath, "LifeValCalculator", 1, 1);
		String lifeCoverVal=XLUtils.getCellData(excelPath, "LifeValCalculator", 1, 2);
		String debtPendVal=XLUtils.getCellData(excelPath, "LifeValCalculator", 1, 3);
		String valRORVal=XLUtils.getCellData(excelPath, "LifeValCalculator", 1, 4);
		String valROIVal=XLUtils.getCellData(excelPath, "LifeValCalculator", 1, 5);
		String expectedLifeCoverVal=XLUtils.getCellData(excelPath, "LifeValCalculator", 1, 6);
		logger = extent.createTest("Calculator");
		extentTest.set(logger);
		hp.genericClick(androiddriver, hp.calculatorButton);
		logger.pass("Clicked on Calculator Button");
		hp.genericClick(androiddriver, hp.termPlanCalButton);
		logger.pass("Clicked on term plan calculator");
		hp.genericSendKeys(androiddriver, hp.monthlyExpField,monthlyExp);
		logger.pass("Monthly Expense Entered is"+" "+monthlyExp);
		hp.genericSendKeys(androiddriver, hp.reqMoneyForYearsTxt, reqYears);
		logger.pass("Money require years entered is"+" "+reqYears);
        fun.scrollToText("Assumptions",androiddriver);
		hp.genericSendKeys(androiddriver, hp.takenLifeCoverTxt, lifeCoverVal);
		logger.pass("Life cover value Entered is"+" "+lifeCoverVal);
		hp.genericSendKeys(androiddriver, hp.pendingDebtTxt, debtPendVal);
		logger.pass("Debt value entered is"+" "+debtPendVal);
		hp.genericClick(androiddriver, hp.addAssumpBtn);
		logger.pass("Clicked on Add assumptions");
        fun.scrollToText("Calculate",androiddriver);
		hp.genericSendKeys(androiddriver, hp.rorEditTxt, valRORVal);
		logger.pass("ROR value entered is"+" "+valRORVal);
		hp.genericSendKeys(androiddriver, hp.inflationRateTxt, valROIVal);
		logger.pass("ROI value entered is"+" "+valROIVal);
		hp.genericClick(androiddriver, hp.calculateBtn);
		logger.pass("Clicked on calculate Button");
	  String actualNetLifeCover=androiddriver.findElement(hp.netLifeCoverVal).getText();
		System.out.println(actualNetLifeCover);
	  Assert.assertEquals(actualNetLifeCover, expectedLifeCoverVal);
		
		
		
	}
}
