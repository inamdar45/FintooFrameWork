package testcases;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.android.AndroidTouchAction;
import io.appium.java_client.touch.LongPressOptions;
import io.appium.java_client.touch.offset.ElementOption;
import pages.HomePage;
import pages.PlanPage;
import utilities.Functions;

public class FinancialPlanning extends BaseClass {
	
	Login lg = new Login();
	Functions fun = new Functions(androiddriver);
	PlanPage pp = new PlanPage(androiddriver);
	HomePage hp = new HomePage(androiddriver);
	@Test(priority=1)
	public void login() throws InterruptedException, IOException {
		lg.login();
		hp.genericClick(androiddriver, hp.letsStartLabel);
		logger.pass("Clicked on Lets Start.");
		
		if(fun.isElementDisplayed(pp.continuePlanningBtn, androiddriver)) {
			pp.genericClick(androiddriver, pp.continuePlanningBtn);
			logger.pass("Clkicked on Continue Planning Button");
		}
	}
	@Test(priority=2)
	public void income() throws IOException {
		logger = extent.createTest("Details for income");
		extentTest.set(logger);
		pp.genericClick(androiddriver, pp.incomeLabel);
		logger.pass("Clicked on Income");
		Map<String,String> Data= fun.getTestDataInMap(excelPath, "Datagathering").get(0);
		String incomeType=Data.get("IncomeType");
		String netIncomeVal = Data.get("NetIncomeValue");
		String incomeFrom = Data.get("IncomeFrom");
		String incomeFixOrVar = Data.get("IncomeFixOrVar");
		String incomeOneTimeOrRecurr = Data.get("OneTimeOrRecurr");
		String incomeStartDate = Data.get("IncomeStartDate");
		By incomeTypElement = By.xpath("//android.widget.TextView[contains(@text,'"+incomeType+"')]");
		pp.genericClick(androiddriver, incomeTypElement);
		logger.pass("Selected income Type is"+" "+incomeType);
		pp.genericSendKeys(androiddriver, pp.netIncomeValTxt, netIncomeVal);
		logger.pass("Net income value entered is"+ " "+netIncomeVal);
		pp.genericClick(androiddriver, pp.incomeFrom);
		By incomFromElement = By.xpath("//android.widget.TextView[contains(@text,'"+incomeFrom+"')]");
		pp.genericClick(androiddriver, incomFromElement);
		logger.pass("Selected income from"+ " "+incomeFrom);
		if(!incomeFixOrVar.contains("Fixed")) {
			pp.genericClick(androiddriver, pp.fixVarToggBtn);
		}
		logger.pass("Selected Income as"+" "+incomeFixOrVar);
		if(!incomeOneTimeOrRecurr.contains("Recurring")) {
			pp.genericClick(androiddriver, pp.oneRecurToggBtn);
		}
		logger.pass("Selected Income as"+" "+incomeOneTimeOrRecurr);
		pp.genericClick(androiddriver, pp.incomeStartDateField);
		logger.pass("Clicked on income start Date drop down");
		calender01(incomeStartDate);
		logger.pass("Income start Date selected is"+" "+incomeStartDate);
		pp.genericClick(androiddriver, pp.endDateAnnualIncomeField);
		
		
		
		
	}
	public void calender01(String date) {
		String[] goalEndDate = date.split("-");
		String date01 = goalEndDate[0];
		String month = goalEndDate[1];
		month = month.substring(0, 3);
		String year = goalEndDate[2];

	/*	Select s = new Select(androiddriver.findElement(dG.calenderYear));
		s.selectByVisibleText(year);
		Select ss = new Select(androiddriver.findElement(dG.calenderMonth));
		ss.selectByVisibleText(month);
		// By date01 = By.xpath("(//a[text()='"+date+"'])[2]");
		By date02 = By.xpath("//*[@id='ui-datepicker-div']//a[text()='" + date01 + "']");
		driver.findElement(date02).click();
		logger.pass("Selected Date is" + " " + date);*/
		String actualYear =androiddriver.findElement(pp.calenderYear).getText();
		while(!actualYear.equalsIgnoreCase(year)) {
			pp.genericClick(androiddriver, pp.monthYearNext);
			By dateElement = By.xpath("//android.view.View[@text='"+date01+"']");
			pp.genericClick(androiddriver, dateElement);
			actualYear =androiddriver.findElement(pp.calenderYear).getText();
		}
		String actualMonth =androiddriver.findElement(pp.calenderMonthDate).getText();
		while(!actualMonth.contains(month)) {
			pp.genericClick(androiddriver, pp.monthYearNext);
			By dateElement = By.xpath("//android.view.View[@text='"+date01+"']");
			pp.genericClick(androiddriver, dateElement);
			actualMonth =androiddriver.findElement(pp.calenderMonthDate).getText();
		}
		By dateElement = By.xpath("//android.view.View[@text='"+date01+"']");
		pp.genericClick(androiddriver, dateElement);
		pp.genericClick(androiddriver, pp.calenderOkButton);
		
	}
	
	public void setSliderValue(WebElement seekBar, int intToSlideValue) {
		//WebElement seekBar = getElement(elementType, elementName);
		
		//Get start point of seekbar.
	/*    int startX = seekBar.getLocation().getX();
	    
	    //Get vertical location of seekbar.
	    int yAxis = seekBar.getLocation().getY();
	    
	    //Set slidebar move to position.
	    // this number is calculated based on (offset + 3/4width)
	    int moveToXDirectionAt = intToSlideValue + startX;
	    
	    //Moving seekbar using TouchAction class.
	    AndroidTouchAction  act=new AndroidTouchAction (androiddriver);
	    act.longPress(startX,yAxis).moveTo(moveToXDirectionAt,yAxis).release().perform();
	    act.longPress(LongPressOptions.longPressOptions()
                .withElement (ElementOption.element (seekBar)))
              .perform ();*/
	}
	
	public void horizontalSwipeByPercentage (double startPercentage, double endPercentage, double anchorPercentage) {
       /* Dimension size = androiddriver.manage().window().getSize();
        int anchor = (int) (size.height * anchorPercentage);
        int startPoint = (int) (size.width * startPercentage);
        int endPoint = (int) (size.width * endPercentage);
        new TouchAction(androiddriver)
            .press(point(startPoint, anchor))
            .waitAction(waitOptions(ofMillis(1000)))
            .moveTo(point(endPoint, anchor))
            .release().perform();*/
    }

}
