package utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import testcases.BaseClass;

public class Functions extends BaseClass  {


	//public AndroidDriver<WebElement> androiddriver;
	public ArrayList<String> tabs;
	String otp;
	
	
	public Functions(AndroidDriver<MobileElement> androiddriver) {
		this.androiddriver=androiddriver;
		//PageFactory.initElements(androiddriver, this);
	}
	
	/*public  static boolean waitTillElementisDisplayed(By element,long timeOutInSeconds) {
		WebDriverWait wait=new WebDriverWait(driver,timeOutInSeconds);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(element)));
	
		return true;
	}*/
	
	public String isFileDownloaded() throws Exception {
	   /* final int SLEEP_TIME_MILLIS = 1000;
	  String  filePath= "//C:/Users/Hp/Downloads/minty";
	    File file = new File(filePath);
	    final int timeout = 60* SLEEP_TIME_MILLIS;
	    int timeElapsed = 0;
	    while (timeElapsed<timeout){
	        if (file.exists()) {
	            System.out.println(file.getName()+"  is present");
	            return true;
	        } else {
	            timeElapsed +=SLEEP_TIME_MILLIS;
	            Thread.sleep(SLEEP_TIME_MILLIS);
	        }
	    }
	    return false;*/
		
		String folderName = "//C:/Users/Hp/Downloads/"; // Give your folderName Downloads
		File[] listFiles = new File(folderName).listFiles();
		String fileName="null";
		for (int i = 0; i < listFiles.length; i++) {

		    if (listFiles[i].isFile()) {
		         fileName = listFiles[i].getName();
		        if (fileName.startsWith("Invoice")
		                && fileName.endsWith(".pdf")) {
		            System.out.println("found file" + " " + fileName);
		            
		        }
		    }
		}
		return fileName;
		
	}
	
    /* public void scrollToElement(WebElement element) throws InterruptedException, AWTException {
    	 Robot r = new Robot();
    	 
    	 while(!element.isDisplayed()) {
    		 r.keyPress(KeyEvent.VK_DOWN);
    		 r.keyRelease(KeyEvent.VK_DOWN);
    		 Thread.sleep(1000);
    	 }
     }*/
	
   /*  public void scrollToElementUp(WebElement element) throws InterruptedException, AWTException {
    	 Robot r = new Robot();
    	 
    	 while(!element.isDisplayed()) {
    		 r.keyPress(KeyEvent.VK_UP);
    		 r.keyRelease(KeyEvent.VK_UP);
    		 Thread.sleep(1000);
    	 }
     }*/
     
   /*  public void waitTillElementClickable(By element) {
    	 
    	 new WebDriverWait(driver, 20).until(ExpectedConditions.elementToBeClickable(driver.findElement(element)));
     }
     
     public void waitTillElementVisible(By element) {
    	
    	 new WebDriverWait(driver, 20).until(ExpectedConditions.visibilityOf(driver.findElement(element)));
     
    	
     }*/
     
     public ArrayList<String>  getDataList(String excelPath,String sheetName) throws IOException {
    	 ArrayList<String> datagatheringList5=new ArrayList<>();
    	 int rowsize = XLUtils.getRowCount(excelPath, sheetName);
 		int colsize = XLUtils.getCellCount(excelPath, sheetName, rowsize);
 		
 		for(int i=5;i<=rowsize;i++) {
 			for(int j=0;j<=colsize;j++) {
 		//	String	key=XLUtils.getCellData(excelPath, "Datagathering", 0, j);
 			
 			String abc=XLUtils.getCellData(excelPath, sheetName, i, j);
 			datagatheringList5.add(abc);
 		//	dGMap.put(key, value)
 			}
 		}
 		return datagatheringList5 ;
     }
     
     
     public  List<Map<String,String>> getTestDataInMap(String sheetPath,String sheetName) throws IOException{
    	 List<Map<String,String>> testDataAllRows=null;
    	 Map<String,String> testData=null;
    	 
    	 try {
    		 FileInputStream fileInputStream = new FileInputStream(sheetPath);
    		 Workbook wb = new XSSFWorkbook(fileInputStream);
    		 Sheet sheet = wb.getSheet(sheetName);
    		 int lastRowNo=sheet.getLastRowNum();
    		 int lastColumnNo= sheet.getRow(0).getLastCellNum();
    		 
    		 List list = new ArrayList();
    		 for (int i = 0; i <lastColumnNo; i++) {
    			 Row row=sheet.getRow(0);
    			  Cell cell=row.getCell(i);
    			String rowHeader= cell.toString().trim();
				list.add(rowHeader);
			}
    		 testDataAllRows = new ArrayList<Map<String,String>>();
    		 for (int j = 1; j <=lastRowNo; j++) {
    			 
    			 Row row = sheet.getRow(j);
    			 testData= new TreeMap<String,String>(String.CASE_INSENSITIVE_ORDER);//treemap preserve's insertion order
    			 for (int k = 0; k < lastColumnNo; k++) {
					Cell cell=row.getCell(k);
			try{
				String cellValue=cell.toString().trim();
				testData.put((String) list.get(k), cellValue);}
			catch(Exception e) {
				
			}
					
				}
				testDataAllRows.add(testData);
			}
    		 
    	 }
    	 catch(FileNotFoundException e) {
    		 e.printStackTrace();
    	 }
    	 return testDataAllRows;
     }
     
   /*  public  boolean isElementDisplayed(By element) {
    	 try {
    		 waitTillElementisDisplayed(element,10);
    	driver.findElement(element);
    	    	    	 }
    	 catch(Exception e) {
    		
    		 return false;
    	 }
    	 return true;
     }*/
     
     public void scrollToText(String text,AndroidDriver<MobileElement> androiddriver) {
    	 
    	 String uiSelector = "new UiSelector().textMatches(\"" + text
                 + "\")";

 String command = "new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView("
                 + uiSelector + ");";

 androiddriver.findElementByAndroidUIAutomator(command);
     }
     
     public boolean isElementDisplayed(By element, AndroidDriver<MobileElement> androiddriver) {
    	 try {
    	 androiddriver.findElement(element);}
    	 catch(Exception e) {
    		 return false;
    	 }
    	 return true;
     }
     
     

}
